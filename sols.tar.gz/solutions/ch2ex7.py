from numpy import sinh,pi

n = 1.
theproduct = 1.
while 1/n**2 > 1e-10:
    theproduct *= 1 + 1/n**2
    n += 1

print theproduct
print sinh(pi)/pi
