
def DFT(samples):
    from numpy import exp
    N = len(samples)
    gamma = []
    for k in range(N//2+1):
        gammaK = 0
        for n,yn in enumerate(samples):
            gammaK += yn * exp(-2j * pi * k * n/N )
        gamma.append(2* gammaK/N)

    return gamma


from numpy import linspace,sin,pi,arange,abs
from matplotlib import pyplot

fS = 600  #Rate at which I sample the function
dt = 1/fS  # time between adjacent samples
samplingTime = 1/120 * 100  # How long do I sample my function
nSamples = samplingTime/dt  # How many samples am I going to take


t = linspace(0,samplingTime,nSamples)  #Location of samples in domain

f = sin(4 * 2 * pi * t) + 5 * sin(120 * 2 * pi * t) # Function samples
gamma = DFT(f)
k = linspace(0,fS//2,nSamples/2 + 1)
print(k)
from numpy import imag,real
pyplot.figure(1)
pyplot.scatter(t,f)
pyplot.figure(2)
pyplot.scatter(k,abs(imag(gamma)))
pyplot.figure(3)
pyplot.scatter(k,abs(real(gamma)))
pyplot.show()
