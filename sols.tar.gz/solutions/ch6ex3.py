from numpy import sinh,arange,pi,cos,sin
from matplotlib import pyplot



class projectile():

    def __init__(self, g = 9.8, dt = 0.1):
        self.g = g
        self.dt = dt


    def setDragSettings(self,A,C,m,rho,variablerho = False,rho0 = 1.29, a = 6.5e-3,T0 = 320,alpha = 2.5):
        # Most of the logic here is for part d
        if not variablerho:
            self.variablerho = False
            self.dragFactor = 1/2. * A * C * rho/m  #Only include this line for previous parts
        else:
            self.variablerho = True
            self.rho0 = rho0
            self.a = a
            self.T0 = T0
            self.alpha = alpha
            self.constant = 1/2. * A * C/m


    def rho(self,y):
        return self.rho0 * ( 1 - self.a * y /self.T0)**self.alpha

    def setInitialConditions(self,r,v):
        self.initialPos = r
        self.initialV = v

    def Euler(self):
        from numpy.linalg import norm

        self.x = [self.initialPos[0]]
        self.y = [self.initialPos[1]]
        vx = self.initialV[0]
        vy = self.initialV[1]

        while self.y[-1] > 0:

            speed = norm([vx,vy])
            if self.variablerho:
                self.dragFactor = self.constant * self.rho(self.y[-1])
            dragX = self.dragFactor * speed * vx
            dragY = self.dragFactor * speed * vy
            self.y.append(self.y[-1] + vy * self.dt)
            self.x.append(self.x[-1] + vx * self.dt)
            vy = vy - (dragY + self.g) * self.dt
            vx = vx - dragX * self.dt

    def plotTrajectory(self):
        from matplotlib import pyplot
        pyplot.plot(self.x,self.y)
        # pyplot.show()


from numpy import exp
speed = 700
angle = 45 * pi/180.
area = 0.007
mass = 50
C = 0.5
rho = 1.29

# Without density correction
trajectoryOne = projectile(dt=0.01)
trajectoryOne.setInitialConditions([0,1],[speed * cos(angle),speed * sin(angle)])
trajectoryOne.setDragSettings(area,C,mass,rho,variablerho = False)
trajectoryOne.Euler()
trajectoryOne.plotTrajectory()

# With density correction.
trajectoryTwo = projectile(dt=0.01)
trajectoryTwo.setInitialConditions([0,1],[speed * cos(angle),speed * sin(angle)])
trajectoryTwo.setDragSettings(area,C,mass,rho,variablerho = True)
trajectoryTwo.Euler()
trajectoryTwo.plotTrajectory()
print abs(trajectoryTwo.x[-1] - trajectoryOne.x[-1])
pyplot.show()

