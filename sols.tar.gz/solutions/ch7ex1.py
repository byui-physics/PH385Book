class pendulum():
    def __init__(self,l,thetaI, omegaI,tMax = 10,dt = 0.1,g=9.8):
        self.g = g
        self.l = l
        self.theta = [thetaI]
        self.omega = [omegaI]
        self.dt = dt
        self.tMax = tMax


    def Euler(self):
        from numpy import arange,sin
        self.time = arange(0,self.tMax,self.dt)

        for t in self.time:
            self.omega.append(self.omega[-1] - self.g/self.l * self.theta[-1] * self.dt)
            self.theta.append(self.theta[-1] + self.dt * self.omega[-2])

    def RK2(self):
        from numpy import arange,sin
        self.time = arange(0,self.tMax,self.dt)

        for t in self.time:
            thetaHalf = self.theta[-1] + self.dt/2 * self.omega[-1]
            omegaHalf = self.omega[-1] - self.dt/2 * self.g/self.l * self.theta[-1]
            self.theta.append(self.theta[-1] + self.dt * omegaHalf)
            self.omega.append(self.omega[-1] - self.g/self.l * thetaHalf * self.dt)


    def plot(self):
        from matplotlib import pyplot

        pyplot.plot(self.time,self.theta[:-1])
        pyplot.show()


from numpy import pi
l = 1.
thetaI =0.2
omegaI = 0.

myPend = pendulum(l,thetaI,omegaI,dt=0.05,tMax = 100)
myPend.RK2()
myPend.plot()
