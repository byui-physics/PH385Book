from numpy import sinh,arange
from matplotlib import pyplot

a = 0
b = 2
N = 100.
dx = (b  - a)/ N  # grid seperation

x = arange(a+dx/2,b+dx/2,dx)
y = sinh(x)

yExtrapLinear = 2 * y[-1] - y[-2]
yExtrapQuad = y[-3] - 3 * y[-2] + 3 * y[-1]
yExtrapExact = sinh(x[-1] + dx)
print yExtrapLinear, yExtrapQuad, yExtrapExact
yInterpLinear =  y[-2] + 1/2. * (y[-1] - y[-2])
yInterpQuad = 1/8. * (-y[-3] + 6 * y[-2] + 3 * y[-1])
yInterpExact = sinh(x[-2] + dx/2.)
print yInterpLinear, yInterpQuad, yInterpExact
