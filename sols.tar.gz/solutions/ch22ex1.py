


class MD:

    def __init__(self,nParticles,boxSize,dt,tMax):
        from numpy import zeros
        self.nParticles = nParticles
        self.boxSize = boxSize
        self.dt = dt
        self.tMax = tMax

    def turnOnHardWalls(self):
        self.hardWalls = True

    def initializeParticlesRandom(self):
        from numpy.linalg import norm
        from numpy.random import uniform
        from numpy import copy
        v0 = 10.0
        index = 0
        self.positions = zeros([self.nParticles,2])
        self.velocities = zeros([self.nParticles,2])

        while index < self.nParticles:
            tooClose = False
            randomVector = uniform(0,self.boxSize,size = 2)
            for i in self.positions:
                distance = norm(randomVector - i)

                if distance < 1:
                    tooClose = True
                    break
            if tooClose:
                continue

            self.positions[index] = copy(randomVector)
            self.velocities[index] = v0 * uniform(-1,1,size = 2)
            index += 1


    def initializeParticlesLattice(self,lVecs):
        from numpy.random import uniform
        from numpy import any,copy,zeros
        index = 0
        v0 = 10
        self.positions = zeros([1000,2])
        self.velocities = zeros([1000,2])
        for i in range(-self.boxSize,self.boxSize):
            for j in range(-self.boxSize,self.boxSize):
                candidate = i * lVecs[0] + j * lVecs[1] + 0.5# + 0.001 * uniform(-1,1,size = 2)
                print(candidate)
                if any(candidate > self.boxSize) or any(candidate < 0.1):
                    print('not adding')
                    continue
                self.positions[index] = candidate
                self.velocities[index] = v0 * uniform(-1,1,size = 2)
                index += 1
        self.nParticles = index
        print(index, 'no of particles')
        self.positions = copy(self.positions[:index])
        self.velocities = copy(self.velocities[:index])
        print(self.positions)



    def getForceOnSingleParticle(self,particle):
        from numpy import array,copy,sign
        from numpy.linalg import norm
        fX = 0
        fY = 0
        for i in self.positions:

            xDiff = (particle - i)[0]
            yDiff = (particle - i)[1]

            if not self.hardWalls:
                if abs(xDiff) > self.boxSize/2 and abs(yDiff) > self.boxSize/2:
                    modifiedPos = array([i[0] + sign(xDiff) * self.boxSize,i[1] + sign(yDiff) * self.boxSize])
                elif abs(xDiff) > self.boxSize/2:
                    modifiedPos = array([i[0] + sign(xDiff) * self.boxSize,i[1]])
                elif abs(yDiff) > self.boxSize/2:
                    modifiedPos = array([i[0],i[1] + sign(yDiff) * self.boxSize])
                else:
                    modifiedPos = copy(i)
            else:
                modifiedPos = copy(i)
            xDiff = (particle - modifiedPos)[0]
            yDiff = (particle - modifiedPos)[1]
            distance = norm(particle - modifiedPos)
            if 0.1 < distance < 4:
                fX += 24 * (2/distance**13 - 1/distance**7) * xDiff/distance
                fY += 24 * (2/distance**13 - 1/distance**7) * yDiff/distance
        return array([fX,fY])


    def checkBoundary(self):
        # Now let's handle the boundary conditions, whether
        # they are hard walls or periodict
        for i,k in enumerate(self.positions):
            if k[0] > self.boxSize:
                if self.hardWalls:
                    self.positions[i][0] = self.boxSize - (self.positions[i][0] - self.boxSize)
                    self.velocitiesHalf[i][0] *= -1
                else:
                    self.positions[i][0] = self.positions[i][0] - self.boxSize
            if k[0] < 0:
                if self.hardWalls:
                    self.positions[i][0] = -1 * self.positions[i][0]
                    self.velocitiesHalf[i][0] *= -1
                else:
                    self.positions[i][0] = self.positions[i][0] + self.boxSize

            if k[1] > self.boxSize:
                if self.hardWalls:
                    self.positions[i][1] = self.boxSize - (self.positions[i][1] - self.boxSize)
                    self.velocitiesHalf[i][1] *= -1
                else:
                    self.positions[i][1] = self.positions[i][1] - self.boxSize
            if k[1] < 0:
                if self.hardWalls:
                    self.positions[i][1] = -1 * self.positions[i][1]
                    self.velocitiesHalf[i][1] *= -1
                else:
                    self.positions[i][1] = self.positions[i][1] + self.boxSize

    def animate(self,speed = 10):
        from numpy import zeros
        index = 0
        time = 0

        forces = zeros([self.nParticles,2])
        for i,k in enumerate(self.positions):
            fVec = self.getForceOnSingleParticle(k)
            forces[i] = fVec
        self.velocitiesHalf = self.velocities + self.dt/2 * forces

        while time < self.tMax:
            if index % speed == 0:
                self.plotSimCell(anim=True)


            self.positions = self.positions + self.dt * self.velocitiesHalf

            forces = zeros([self.nParticles,2])
            for i,k in enumerate(self.positions):
                fVec = self.getForceOnSingleParticle(k)
                forces[i] = fVec

            self.velocitiesHalf = self.velocitiesHalf + self.dt * forces

            self.checkBoundary()


            index += 1
            time += self.dt
    def plotSimCell(self,anim = False):
        from matplotlib import pyplot
        pyplot.scatter([n[0] for n in self.positions],[n[1] for n in self.positions])
        pyplot.xlim(0,self.boxSize)
        pyplot.ylim(0,self.boxSize)
        if anim:
            pyplot.draw()
            pyplot.pause(1e-5)
            pyplot.clf()
        else:
            pyplot.show()

from numpy import array
nParticles = 20
boxSize = 10
lVecs = 3 * array([ array([1,0]), array([0,1])])
dt = 0.0001
tMax = 16
speed = 20
myMD = MD(nParticles,boxSize,dt,tMax)
#myMD.initializeParticlesRandom()
myMD.turnOnHardWalls()
myMD.initializeParticlesLattice(lVecs)
myMD.animate(speed)
myMD.getForceOnSingleParticle(myMD.positions[0])
myMD.plotSimCell()

