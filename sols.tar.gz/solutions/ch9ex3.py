class lorenz():
    def __init__(self,tMax = 60, dt = .01,sigma = 10, b = 8./3., r = 5):
        self.dt = dt
        self.tMax = tMax
        self.sigma = sigma
        self.b = b
        self.r = r

    def setInitialConditions(self,x,y,z):
        self.x = [x]
        self.y = [y]
        self.z = [z]

    def getDerivs(self,varsVec):
        from numpy import array,pi,sin
        from numpy.linalg import norm
        # Varsvec [theta,omega]
        x = varsVec[0]
        y = varsVec[1]
        z = varsVec[2]
        dx = self.sigma * (y - x)
        dy = - x * z + self.r * x - y
        dz = x * y - self.b * z
        return array([dx,dy,dz])


    def RK4(self):
        from numpy import array

        r = array([self.x[-1],self.y[-1],self.z[-1]])
        t = 0
        self.time = [t]
        while t < self.tMax:
            k1 = self.dt * self.getDerivs(r)
            k2 = self.dt * self.getDerivs(r + 1/2. * k1)
            k3 = self.dt * self.getDerivs(r + 1/2. * k2)
            k4 = self.dt * self.getDerivs(r + k3)
            r  +=1/6. * (k1 + 2. * k2 + 2. * k3 + k4 )

            self.x.append( r[0]  )
            self.y.append(r[1])
            self.z.append(r[2])
            t += self.dt
            self.time.append(t)


    def leapfrog(self):
        from numpy import arange,sin,array
        from numpy.linalg import norm

        # Use Euler to perform the first half time step
        r = array([self.x[-1],self.y[-1],self.z[-1]])
        k1 = self.dt * self.getDerivs(r)
        midPointVars = r + 1/2. * k1
        # Done with first half time step.

        t = 0
        self.time = [t]

        while t < self.tMax:
            # Using the midpoint, make a full step
            k2 = self.dt * self.getDerivs(midPointVars)
            r += k2
            # Step from the previous midPoint to the next midPoint.
            midPointVars = midPointVars + self.dt * self.getDerivs(r)
            self.x.append(r[0])
            self.y.append(r[1])
            self.z.append(r[2])
            t += dt
            self.time.append(t)



    def plot(self):
        from matplotlib import pyplot
        pyplot.figure()
        pyplot.plot(self.time,self.z)
        pyplot.show()

    def phaseSpace(self,show = True):
        from matplotlib import pyplot
        pyplot.scatter(self.x,self.z)
        if show:
            pyplot.show()

    def plot3D(self):
        from mpl_toolkits.mplot3d import Axes3D
        fig = pyplot.figure()
        fig.gca(projection= '3d')
        pyplot.plot(self.x,self.y,self.z)
        pyplot.axis('equal')
        pyplot.show()

from numpy import pi,array,abs
from matplotlib import pyplot
import sys
x = 1.
y = 0.
z = 0.

weatherOne = lorenz(r = 25)
weatherOne.setInitialConditions(x,y,z)
weatherOne.RK4()
#weatherOne.phaseSpace()
weatherOne.plot3D()
#weatherOne.plot()
sys.exit()
