
class BVP():

    def __init__(self,a,b,N):
        from numpy import linspace
        self.N = N
        self.x,self.dx = linspace(a,b,N,retstep=True)


    def loadAMatrix(self):
        from numpy import zeros,sin,cos,copy
        # Load A
        self.A = zeros([self.N,self.N])
        self.A[0][0] = 1
        self.A[self.N-1][self.N-1] = 1


        for i in range(1,N-1):
            self.A[i][i] = -2./self.dx**2
            self.A[i][i+1] = 1./self.dx**2
            self.A[i][i-1] = 1./self.dx**2


    def solveProblem(self):
        from numpy.linalg import solve
        from numpy import ones, sin,matmul

        self.y = ones(self.N)

        errorVec = abs(matmul(self.A,self.y) - (1 - sin(self.y)))[1:self.N-1]
        while (errorVec > 1e-5).any():
            b = 1 - sin(self.y)
            b[0] = 0
            b[-1] = 0
            self.y = solve(self.A,b)
            errorVec = abs(matmul(self.A,self.y) - (1 - sin(self.y)))[1:self.N-1]


    def plot(self):
        from matplotlib import pyplot
        pyplot.plot(self.x,self.y,'r.')
        pyplot.show()
from matplotlib import pyplot
a = 0
b = 3
N = 30

myBVP = BVP(a,b,N)
myBVP.loadAMatrix()
myBVP.solveProblem()
myBVP.plot()

