class orbit():
    def __init__(self,tMax = 1,dt = 0.01, mEarth = 5.98e24):
        self.dt = dt
        self.tMax = tMax
        self.mEarth = mEarth
    def setInitialConditions(self,r,v):
        self.r = [r]
        self.v = [v]


    def getDerivs(self,varsVec):
        from numpy import sin,array
        from numpy.linalg import norm
        v = varsVec[2:]
        r = array(varsVec[:2])
        xDeriv = v[0]
        yDeriv = v[1]

        vxDeriv = - 4 * pi**2 * varsVec[0]/norm(r)**3.5
        vyDeriv = - 4 * pi**2 * varsVec[1]/norm(r)**3.5

        return array([xDeriv,yDeriv,vxDeriv,vyDeriv])

    def leapfrog(self):
        from numpy import arange,sin,array
        from numpy.linalg import norm

        # Use Euler to perform the first half time step
        r = array([self.r[0][0],self.r[0][1],self.v[0][0],self.v[0][1]])
        k1 = self.dt * self.getDerivs(r)
        midPointVars = r + 1/2. * k1
        # Done with first half time step.

        self.E = [1/2. * self.mEarth * norm(r[2:])**2 - 4 * pi**2 * self.mEarth/norm(r[:2])]
        self.t = [0]
        while self.t[-1] < self.tMax:
            # Using the midpoint, make a full step
            k2 = self.dt * self.getDerivs(midPointVars)
            r += k2
            # Step from the previous midPoint to the next midPoint.
            midPointVars +=  self.dt * self.getDerivs(r)
            self.r.append([r[0],r[1]])
            self.v.append([r[2],r[3]])
            self.t.append(self.t[-1] + self.dt)
            self.E.append(1/2. * self.mEarth * norm(r[2:])**2 - 4 * pi**2 * self.mEarth/norm(r[:2]))


    def plot(self):
        from matplotlib import pyplot
        x = [var[0] for var in self.r]
        y = [var[1] for var in self.r]
        pyplot.plot(x,y)
        pyplot.show()

    def plotEnergy(self):
        from matplotlib import pyplot
        print len(self.t), len(self.K)
        pyplot.plot(self.t,self.E)
        pyplot.show()

from numpy import pi
r = [1,0]
v = [0,2 * pi - 1.2]

myOrbit = orbit(tMax = 5,dt = 0.001)
myOrbit.setInitialConditions(r,v)
myOrbit.leapfrog()
myOrbit.plot()
