



class TwoDWave():

    def __init__(self,a,b,c,d,Nr,Ntheta,mu,sigma,tau,tMax):
        from numpy import linspace,meshgrid,sqrt,cos,sin,arange
        self.tau = tau
        self.mu = mu
        self.sigma = sigma
        self.Nr = Nr
        self.N = Nr
        self.Ntheta = Ntheta
        self.tMax = tMax
        self.c = sqrt(sigma/mu)
        self.dtheta = (d - c)/Ntheta
        self.dr = (b - a)/Nr
        print(a,b,self.dr,Nr)
        r = arange(a - self.dr/2,b + self.dr,self.dr)
        theta = arange(c - self.dtheta/2,d + self.dtheta,self.dtheta)
        self.theta,self.R = meshgrid(theta,r)
        self.X = self.R * cos(self.theta)
        self.Y = self.R * sin(self.theta)
#        print(r)
#        print(self.R, 'R')
#        print(self.theta,'theta')
#        print(self.X)
#        print(self.Y,'y')
#        import sys
#        sys.exit()
#        print(self.dr)
        print( "Courant condition: ", self.dr/self.c/sqrt(2))
        if self.tau > 1/( sqrt(2)) *  self.dr/self.c:
            print(self.tau)
            print(1/( sqrt(2)) *  self.dr/self.c)
            print("Instability headed your way!")
            import sys
            sys.exit()

    def initializeWave(self):
        from numpy import zeros_like,exp,cos
        from matplotlib import pyplot,cm
        from mpl_toolkits.mplot3d import Axes3D
        from scipy.special import jv, jn_zeros

        kth_zero = jn_zeros(1, 1)
        self.Z = cos(self.theta) * jv(1, kth_zero*self.R/4)
        self.Z = exp(-2 *((self.X - 0.5)**2 + (self.Y-0.5)**2) )
        self.v = zeros_like(self.Z)
        #        self.Z[0] = 0
        self.Z[-1] = 0
#        fig = pyplot.figure()
#        ax = fig.gca(projection='3d')
#        ax.plot_wireframe(self.X,self.Y,self.Z)
#        pyplot.show()
#        import sys
#        sys.exit()
        # self.Z[:,0] = 0
        #self.Z[:,-1] = 0
    def animate(self,movie=True):
        from numpy import zeros_like,copy
        from matplotlib import pyplot,cm
        from mpl_toolkits.mplot3d import Axes3D

        constant = self.sigma * self.tau**2 /self.mu
        #        constant = self.c**2 * self.tau**2 /self.dx**2
        zOld = zeros_like(self.Z)
        zOld[1:self.N + 1,1:self.N + 1] = - self.tau * self.v[1:self.N + 1,1:self.N + 1] + self.Z[1:self.N + 1, 1:self.N + 1] + constant/2 * (1/( self.R[1:self.N + 1, 1: self.N + 1] * 2 * self.dr) * (self.Z[2:self.N + 2, 1: self.N + 1] - self.Z[0:self.N, 1: self.N + 1]) + 1/self.dr**2 * (self.Z[2:self.N + 2, 1: self.N + 1] - 2 * self.Z[1:self.N + 1, 1: self.N + 1] + self.Z[0:self.N, 1: self.N + 1]) + 1/self.R[1:self.N + 1, 1: self.N + 1]**2/self.dtheta**2 * (self.Z[1:self.N + 1, 2: self.N + 2] - 2 * self.Z[1:self.N + 1, 1: self.N + 1] + self.Z[1:self.N + 1, 0: self.N])    )
        zOld[-1] = 0

        counter = 0
        t = 0
        fig = pyplot.figure(figsize = (10,8))
        self.singlePoint = []
        while t < self.tMax:
            zNew = zeros_like(self.Z)
            zNew[1:self.N + 1,1:self.N + 1] = 2 * self.Z[1:self.N + 1,1:self.N + 1] - zOld[1:self.N + 1, 1: self.N + 1] + constant * (1/( self.R[1:self.N + 1, 1: self.N + 1] * 2 * self.dr) * (self.Z[2:self.N + 2, 1: self.N + 1] - self.Z[0:self.N, 1: self.N + 1]) + 1/self.dr**2 * (self.Z[2:self.N + 2, 1: self.N + 1] - 2 * self.Z[1:self.N + 1, 1: self.N + 1] + self.Z[0:self.N, 1: self.N + 1]) + 1/self.R[1:self.N + 1, 1: self.N + 1]**2/self.dtheta**2 * (self.Z[1:self.N + 1, 2: self.N + 2] - 2 * self.Z[1:self.N + 1, 1: self.N + 1] + self.Z[1:self.N + 1, 0: self.N])    )
            
            zNew[-1] = - zNew[-2]
            zNew[0] = zNew[1]
            # Periodic boundary conditions for theta = 0 and theta = 2pi.  Found by requiring
            # the value and the derivative be equal at these two points, which are actually the same point.
            zNew[:,0] = zNew[:,-2]
            zNew[:,-1] = zNew[:,1]
            
            
            self.singlePoint.append(self.Z[int(self.N/2),int(self.N/2)])
            if counter %200 == 0 and movie:
                ax = fig.gca(projection='3d')
                ax.plot_surface(self.X[:,:],self.Y[:,:],self.Z[:,:],cmap = cm.gist_rainbow)
                ax.set_axis_off()
                ax.set_zlim(-.35,.35)
                ax.set_xlim(-2.5,2.5)
                ax.set_ylim(-2.5,2.5)

                pyplot.draw()
                pyplot.pause(.0001)
                pyplot.clf()

            zOld = copy(self.Z)
            self.Z = copy(zNew)
            t += self.tau
            counter += 1
    def plotSinglePoint(self):

        from matplotlib import pyplot
        from numpy import linspace
        pyplot.plot(linspace(0,self.tMax,len(self.singlePoint)),self.singlePoint)
        pyplot.show()

from numpy import pi
a = 0
b = 4
c = 0
d = 2 * pi
Nr = 30
mu = 0.3
sigma = 2
tau = .0005
tMax = 50
my2Dwave = TwoDWave(a,b,c,d,Nr,Nr,mu,sigma,tau,tMax)
my2Dwave.initializeWave()
my2Dwave.animate()
my2Dwave.plotSinglePoint()

#from numpy import linspace, meshgrid,exp,sqrt,cos
#from matplotlib import pyplot
#from mpl_toolkits.mplot3d import Axes3D
