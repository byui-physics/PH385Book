from numpy import exp,log


x = 10
omega = 0.64
while abs(x - omega * exp(-x) - (1 - omega) * x) > 1e-5:

    x = omega * exp(-x) + (1 - omega) * x
    print(x)


