from numpy import arange,sin,log,exp,cos

x = 100   # Set initial value
xNew = sin(3 * x)  # Find next value

while abs(x - xNew) > 1e-8:
    x = xNew  # Update old value to be what you just found
    xNew = sin(3 * x)  # Find the next value
    print xNew

