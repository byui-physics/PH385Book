

class CN():

    def __init__(self,a,b,N,tau,D):
        from numpy import arange
        self.L = b
        self.N = N
        self.tau = tau
        self.dx = (b - a)/N
        # cell-centered grid with ghost points.
        self.x = arange(a - self.dx/2, b + self.dx, self.dx)
        self.D = self.diffusionConstant(self.x + self.dx/2)
        self.D = [2 for x in self.x]
    def initializeTprofile(self):
        from numpy import sin, pi
        self.T = sin( pi * self.x/self.L)

    def diffusionConstant(self,x):
        import numpy
        if type(x) is numpy.ndarray:
            from numpy import array
            return array([self.diffusionConstant(var) for var in x])
        else:
            if x < self.L/2:
                return 1.
            elif self.L/2 <= x :
                return 5.


    def loadMatrices(self):
        from numpy import zeros, insert,diag,matrix

        A = zeros([self.N +2, self.N + 2])
        self.B = zeros([self.N +2, self.N + 2])

        for i in range(1,self.N + 1):
            A[i,i-1] = - self.D[i-1]
            A[i,i] = 2 * self.dx**2/self.tau  + (self.D[i] + self.D[i-1])
            A[i,i+1] = - self.D[i]

            self.B[i,i-1] = self.D[i-1]
            self.B[i,i] = 2 * self.dx**2/self.tau  - (self.D[i] + self.D[i-1])
            self.B[i,i+1] = self.D[i]

        A[0,0] = 1/2.
        A[0,1] = 1/2.
        A[-1,-1] = 1/2.
        A[-1,-2] = 1/2.

        # Derivative boundary conditions
       # A[0,0] = -1/self.dx
       # A[0,1] = 1/self.dx
       # A[-1,-1] = 1/self.dx
       # A[-1,-2] = -1/self.dx

        ud = insert(diag(A,1), 0, 0) # upper diagonal
        d = diag(A) # main diagonal
        ld = insert(diag(A,-1), self.N+1, 0) # lower diagonal
        # simplified matrix
        self.ab = matrix([ud,d,ld])
        print(self.ab)
    def animate(self,tMax):
        from numpy import dot,linspace
        from scipy.linalg import solve_banded
        from matplotlib import pyplot
        counter = 0
        t = 0
        while t < tMax:
            if counter %1 == 0:
                pyplot.plot(self.x,self.T,'r.-')
                pyplot.ylim(-0.1,1)
                pyplot.draw()
                pyplot.pause(1e-1)
                pyplot.clf()
            b = dot(self.B,self.T)
            # Boundary conditions: only really needed when the boundary condition isn't zero.
            b[0] = 0
            b[-1] = 0
            self.T = solve_banded((1,1),self.ab,b)

            counter += 1
            t += self.tau

a = 0
b = 10
N = 10
D = 2
tau = 0.5

myHeat = CN(a,b,N,tau,D)
myHeat.initializeTprofile()
myHeat.loadMatrices()
myHeat.animate(100)
