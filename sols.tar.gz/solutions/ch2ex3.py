x = 0.75
thesum = 0
n = 1
while n * x**n > 1e-9:
    thesum += n * x**n
    n = n + 1
    if n > 10000:
        break

checkVal = x /(1 -x)**2
print thesum, checkVal
