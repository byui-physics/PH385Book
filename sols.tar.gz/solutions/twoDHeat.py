

class CN():

    def __init__(self,a,b,N,tau,D):
        from numpy import arange,linspace,meshgrid
        self.L = b
        self.N = N
        self.tau = tau
        self.dx = (b - a)/N
        # cell-centered grid with ghost points.
        self.x = linspace(a , b,N)
        self.y = linspace(a , b,N)
        self.X,self.Y = meshgrid(self.x,self.y)
        self.D = 0.2
        #        self.D = self.diffusionConstant(self.x + self.dx/2)
        #self.D = [2 for x in self.x]
    def initializeTprofile(self):
        from numpy import exp
        self.T_twoD = exp(-(self.X**2 + self.Y**2)/5)


    def decoder(self,i,j):
        return j * self.N + i 

    def backwardDecoder(self,number):
        nOne = number // self.N
        nTwo = number % self.N
        return nTwo,nOne
        

    def twoD_to_oneD(self):
        from numpy import zeros
        self.T = zeros(self.N**2)
        for i in range(0,self.N):
            for j in range(0,self.N):
                self.T[self.decoder(i,j)] = self.T_twoD[i,j]


    def oneD_to_twoD(self):
        from numpy import zeros
        self.T_twoD = zeros([self.N,self.N])

        for index,val in enumerate(self.T):
            i,j = self.backwardDecoder(index)
            self.T_twoD[i,j] = val
            
    def loadMatrices(self):
        from numpy import zeros, insert,diag,matrix
        from scipy.linalg import inv
        A = zeros([self.N**2, self.N**2])
        self.B = zeros([self.N**2, self.N**2])
        counter = 0
        done = False
        for i in range(0,self.N):
            for j in range(0,self.N):
                print(i,j,'--->',self.decoder(i,j))
                print(counter, self.N**2 - 1)
                if counter > self.N**2 -1:
                    done = True
                    break
                if 0 < i < self.N - 1 and 0 < j < self.N - 1:
                    A[counter,self.decoder(i,j)] = 2 * self.D/self.dx**2 + 1/self.tau

                    A[counter,self.decoder(i+1,j)] = -self.D/(2 * self.dx**2) 
                    A[counter,self.decoder(i-1,j)] = -self.D/(2 * self.dx**2) 
                    A[counter,self.decoder(i,j+1)] = -self.D/(2 * self.dx**2) 
                    A[counter,self.decoder(i,j-1)] = -self.D/(2 * self.dx**2) 
                    self.B[counter,self.decoder(i,j)] = 1/self.tau - 2 * self.D/self.dx**2
                    self.B[counter,self.decoder(i-1,j)] = self.D/(2 * self.dx**2)
                    self.B[counter,self.decoder(i+1,j)] = self.D/(2 * self.dx**2)
                    self.B[counter,self.decoder(i,j-1)] = self.D/(2 * self.dx**2)
                    self.B[counter,self.decoder(i,j+1)] = self.D/(2 * self.dx**2)
                    
                else:
                    A[counter,self.decoder(i,j)] = 1
                counter +=1
            if done == True:
                break

        self.invA = inv(A)
        #        print(A)
        #import sys
        #sys.exit()
        #        A[0,0] = 1/2.
        #A[0,1] = 1/2.
        #A[-1,-1] = 1/2.
        #A[-1,-2] = 1/2.

        # Derivative boundary conditions
       # A[0,0] = -1/self.dx
       # A[0,1] = 1/self.dx
       # A[-1,-1] = 1/self.dx
       # A[-1,-2] = -1/self.dx

#        ud = insert(diag(A,1), 0, 0) # upper diagonal
#        d = diag(A) # main diagonal
#        ld = insert(diag(A,-1), self.N+1, 0) # lower diagonal
#        # simplified matrix
#        self.ab = matrix([ud,d,ld])
#        print(self.ab)
    def animate(self,tMax):
        from numpy import dot,linspace
        from scipy.linalg import solve_banded
        from matplotlib import pyplot
        counter = 0
        t = 0
        self.fig = pyplot.figure()
        while t < tMax:
            print(t)
            if counter %10 == 0:
                self.oneD_to_twoD()
                self.plotTemp(animate = True)
            b = dot(self.B,self.T)
            for i in range(0,self.N):
                b[self.decoder(i,0)] = 5
                # Boundary conditions: only really needed when the boundary condition isn't zero.
            #            b[0] = 0
            # b[-1] = 0
            self.T = dot(self.invA,b)

            counter += 1
            t += self.tau

    def plotTemp(self,animate = False):
        from matplotlib import pyplot,cm
        from mpl_toolkits.mplot3d import Axes3D
        if not animate:
            fig = pyplot.figure()
            ax = fig.gca(projection = '3d')
        
        else:
            pyplot.clf()
            ax = self.fig.gca(projection = '3d')
        
        ax.plot_surface(self.X,self.Y, self.T_twoD)#, cmap= cm.gist_rainbow)
        ax.set_zlim(0,1)
        ax.view_init(elev = 25.5,azim = 220)
        if not animate:
            pyplot.show()
        else:
            pyplot.draw()
            pyplot.pause(1e-4)


a = -10
b = 10
N = 40
D = 20
tau = 0.5

myHeat = CN(a,b,N,tau,D)
myHeat.initializeTprofile()
myHeat.twoD_to_oneD()
myHeat.loadMatrices()
myHeat.animate(200)
