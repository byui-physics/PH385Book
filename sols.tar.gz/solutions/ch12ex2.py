class HangingChain():

    def __init__(self,a,b,N):
        from numpy import linspace
        self.L = b
        self.N = N
        self.x,self.dx = linspace(a,b,N,retstep = True)

    def loadMatrices(self):
        from numpy import zeros,sin,cos,eye
        # Load A
        self.A = zeros([self.N,self.N])
        self.A[0,0] = 1
        self.A[-1,-1] = 1

        for i in range(1,self.N-1):
            self.A[i][i] = 1. /self.dx**2 + 1./2. * self.x[i]**2
            self.A[i][i+1] = -1./( 2 * self.dx**2)
            self.A[i][i-1] = -1./( 2 * self.dx**2)

        # Load b
        self.B = eye(self.N)
        self.B[0,0] = 0.
        self.B[-1,-1] = 0.

    def solveProblem(self):
        from scipy.linalg import eig
        from numpy import sqrt,pi
        self.eVals,self.eVecs = eig(self.A,self.B)
        self.key = sorted(range(len(self.eVals)), key=lambda k: self.eVals[k])
        #        self.omega = sorted(self.omega)
    def plot(self,mode):
        from numpy import real,conjugate,sqrt,dot
        from matplotlib import pyplot
        normalization = sqrt( dot( self.eVecs[:,self.key[mode]],conjugate(self.eVecs[:,self.key[mode]])) * self.dx)
        #        print normalization, 'here'
        pyplot.plot(self.x,self.eVecs[:,self.key[mode]] * conjugate(self.eVecs[:,self.key[mode]])/normalization**2,'r.-')
        pyplot.title("mode:  " + str(mode + 1)+ '\n' +  str(real(self.eVals[self.key[mode]])))
        pyplot.xlim(-5,5)
        pyplot.show()


from matplotlib import pyplot
a = -4.
b = 4.
N = 500

myBVP = HangingChain(a,b,N)
myBVP.loadMatrices()
myBVP.solveProblem()
#print myBVP.eVals[1]
myBVP.plot(1)
