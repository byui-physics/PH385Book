from numpy import linspace, sin,cosh,zeros_like,exp
from matplotlib import pyplot
from scipy.special import jv

N = 100
a = 0
b = 5
x,dx = linspace(a,b,N,retstep = True)
y = jv(0,x)

yp = zeros_like(y)
ypp = zeros_like(y)

# Populate the inner values using centered-difference
# formulas
yp[1:N-1] =(y[2:N]-y[0:N-2])/(2*dx)
ypp[1:N-1] =(y[2:N]-2*y[1:N-1]+y[0:N-2])/dx**2

# Calculate derivatives at endpoints using
# linear extrapolation
#yp[0] = 2 * yp[1] - yp[2]
#yp[N-1] = 2 * yp[N-2] - yp[N-3]

#ypp[0] = 2 * ypp[1] - ypp[2]
#ypp[N-1] = 2 * ypp[N-2] - ypp[N-3]

# Calculate derivatives at endpoints using
# quadratic extrapolation
yp[0] = 3 * yp[1] - 3 * yp[2] + yp[3]
yp[N-1] = 3 * yp[N-2] - 3* yp[N-3] + yp[N-4]

ypp[0] = 3 * ypp[1] - 3 * ypp[2] + ypp[3]
ypp[N-1] = 3 * ypp[N-2] - 3 * ypp[N-3] + ypp[N-4]

print("extrapolated value:", yp[0],   "true value:", -jv(1,x[0]) )
print("extrapolated value:", yp[N-1], "true value:", -jv(1,x[N-1]) )
print("extrapolated value:", ypp[0],  "true value:", 0.5 * (-jv(0,x[0]) + jv(2,x[0]) ) )
print("extrapolated value:", ypp[N-1],"true value:", 0.5 * (-jv(0,x[N-1]) + jv(2,x[N-1]) ) )


# Calculate the true derivative functions
realFirst = -jv(1,x)
realSecond = 0.5 * (- jv(0,x) + jv(2,x))

#Plot
pyplot.plot(x,y)
pyplot.plot(x,yp)
pyplot.plot(x,ypp)
pyplot.plot(x,realFirst)
pyplot.plot(x,realSecond)
pyplot.show()
