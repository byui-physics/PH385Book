class BVP():

    def __init__(self,a,b,N):
        from numpy import linspace
        self.N = N
        self.x,self.dx = linspace(a,b,N,retstep=True)


    def loadMatrices(self):
        from numpy import zeros,sin,cos,copy
        # Load A
        self.A = zeros([self.N,self.N])
        self.A[0][0] = 1
        self.A[self.N-1][self.N-1] = 1

        for i in range(1,N-1):
            self.A[i][i] = -2./self.dx**2 + 1. -  1./self.x[i]**2
            self.A[i][i+1] = 1./self.dx**2 + 1./(2. * self.dx * self.x[i])
            self.A[i][i-1] = 1./self.dx**2 - 1./(2 * self.dx * self.x[i])

        # Load b
        self.b = copy(self.x)
        self.b[0] = 0
        self.b[-1] = 1

    def solveProblem(self):
        from numpy.linalg import solve
        self.solution = solve(self.A,self.b)

    def plot(self):
        from matplotlib import pyplot
        pyplot.plot(self.x,self.solution,'r.')
        #        pyplot.show()
    def plotExact(self):
        from scipy.special import jv
        yExact = -4/jv(1,5) * jv(1,self.x) + self.x
        pyplot.plot(self.x,yExact)

from matplotlib import pyplot
a = 0
b = 5
N = 30

myBVP = BVP(a,b,N)
myBVP.loadMatrices()
myBVP.solveProblem()
myBVP.plot()
myBVP.plotExact()
pyplot.show()
