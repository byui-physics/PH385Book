from numpy import linspace, meshgrid,exp,sqrt,cos
from matplotlib import pyplot
from mpl_toolkits.mplot3d import Axes3D

a = 0
b = 2
c = -3
d = 3
Nx = 30
Ny = 50
x,dx = linspace(a,b,Nx,retstep = True)
y,dy = linspace(c,d,Ny,retstep = True)

X,Y = meshgrid(x,y)

z = exp(-(X**2 + Y**2)) * cos(5 * sqrt(X**2 + Y**2))
fig = pyplot.figure()
ax = fig.gca(projection='3d')
ax.plot_surface(X,Y,z)
pyplot.show()
