


class heat():


    def __init__(self,a,b,N,D,tau,stabilityCheck = True):
        from numpy import arange,any
        self.dx = (b - a)/N
        self.N = N
        self.L  = b
        self.tau = tau
        self.D0 = D
        self.x = arange(a - self.dx/2,b + self.dx,self.dx)
        self.D = self.diffusionConstant(self.x + self.dx/2)  # Need to evaluate D in between grid points because
                                                            # that's what comes out of the Crank-Nicholson algorithm
        if stabilityCheck and any(self.tau > self.dx**2/self.D/2):
            import sys
            print('Watch out: Numerical instability headed your way.')
            sys.exit()

    def initialWaveForm(self,ftype,freq = 2):
        from numpy import pi, sin,exp
        if ftype == 'oscillatory':
            self.T = sin(2 * pi * self.x/self.L) + sin(3 * pi * self.x/self.L) + sin(4 * pi * self.x/self.L)
        else:
            self.T = exp(-40*(self.x/self.L - 0.5)**2)

    def diffusionConstant(self,x):
        import numpy
        if type(x) is numpy.ndarray:
            from numpy import array
            return array([self.diffusionConstant(var) for var in x])
        else:
            return 5 * self.D0/self.L * (x**2 + self.L/5)

    def animate(self,tMax,bc='fixed'):
        from numpy import zeros_like,copy
        from matplotlib import pyplot
        constant = 5 * self.D0 * self.tau/(self.L * self.dx)
        constTwo = self.tau /self.dx**2
        TNew = zeros_like(self.T)
        counter = 0
        t = 0
        while t < tMax:
            TNew[1:self.N + 1 ] = self.T[1:self.N + 1 ] + constant * self.x[1:self.N + 1] * (self.T[2:self.N + 2] - self.T[0:self.N])  + constant/self.dx * (self.x[1:self.N + 1]**2 + self.L/5) *  (self.T[2:self.N + 2 ] - 2 * self.T[1:self.N + 1 ] + self.T[0:self.N ])
            #The equation below is more general and emerges when deriving the Crank-Nicholson algorithm.  The equation above arises by putting the specific D(x) into the diffusion equation and discretizing.  They should both work
            #            TNew[1:self.N + 1] = self.T[1:self.N + 1 ] + constTwo *(self.D[1:self.N + 1] *(self.T[2:self.N + 2] - self.T[1: self.N + 1]) - self.D[0:self.N] * (self.T[1:self.N + 1] - self.T[0:self.N]))
            if bc == 'fixed':
                TNew[0] = - TNew[1] # Boundary conditions for ghost points
                TNew[-1] = - TNew[-2]

            elif bc == 'insulating':
                TNew[0] =  TNew[1] # Boundary conditions for ghost points
                TNew[-1] =  TNew[-2]
            self.T = copy(TNew)

            if counter % 1000 == 0:
                pyplot.plot(self.x,self.T,'r.-')
                pyplot.ylim(-1,1)
                pyplot.draw()
                pyplot.pause(.00001)
                pyplot.clf()
            counter += 1
            t += self.tau
            #    def exact(self,x,t):



a = 0
b = 3
N = 80
D = 2
tau = 1e-7


myHeat = heat(a,b,N,D,tau)
myHeat.initialWaveForm(ftype = 'exp')
myHeat.animate(10,bc = 'insulating')
