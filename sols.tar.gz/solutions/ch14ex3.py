class animatedWave():

    def __init__(self,a,L,N,tau,tMax,gamma, mu,stabilityCheck = False):
        from numpy import arange
        self.L = L
        #self.c = c
        self.N = N
        self.tMax = tMax
        self.tau = tau
        self.gamma = gamma
        self.mu = mu
        self.g = 9.8
        self.omegaD = 15.
        self.dx = (b - a)/N


        self.x = arange(a - self.dx/2, b + self.dx,self.dx)

        cTop = self.mu * self.L * self.g
        if self.tau > self.dx/cTop and stabilityCheck:
            print "Beware: You are numerically unstable"
            import sys
            sys.exit()

    def f(self,x):
        import numpy
        if type(x) is numpy.ndarray:
            from numpy import array
            return array([self.f(var) for var in x])
        else:
            if   0.45 < x < 0.5:
                return 1.73
            else:
                return 0
    def initializeWave(self):
        from numpy import exp,zeros

        self.v = zeros(self.N + 2)#exp(-160/self.L**2 * (self.x - self.L/2.)**2) - exp(-160/self.L**2 * (0 - self.L/2.)**2)
        self.y = zeros(self.N + 2)

    def animate(self):
        from numpy import zeros_like,copy,cos
        #        constant = self.c**2 * self.tau**2/(2 * self.dx**2)

        constant = 2 * self.tau**2/(2 + self.gamma * self.tau)

        constantFive = 4 * self.tau**2/(2 + self.gamma * self.tau)
        yOld = zeros_like(self.y)

        t = 0
        counter = 0
        while t < self.tMax:
            yNew = zeros_like(self.y)
            yNew[1:self.N+1] = constant * self.f(self.x[1:self.N + 1])/self.mu * cos(self.omegaD * t) + constant * self.g * (self.y[2:self.N + 2] - self.y[0:self.N])/(2 * self.dx) + constant * self.g * self.x[1:self.N + 1] * (self.y[2:self.N + 2] - 2 * self.y[1:self.N + 1] + self.y[0:self.N])/self.dx**2 + constant * (2 * self.y[1:self.N + 1] - yOld[1:self.N + 1])/self.tau**2 + constant * self.gamma *yOld[1:self.N +1]/(2 * self.tau)
#            print 'first term', - constantFive * (2 - self.gamma * self.tau)/(4 * self.tau**2) *(yOld[1] + yOld[0])
#            print 'second term',  constantFive /self.tau**2 *(self.y[1] + self.y[0])
#            print 'third term', - yNew[1]
#            print 'fourth term', self.g /self.dx * constantFive *(self.y[1] - self.y[0])
#            print 'fifth term',   self.f(0)/self.mu * constantFive * cos(self.omegaD * t)

            yNew[0] =    - constantFive * (2 - self.gamma * self.tau)/(4 * self.tau**2) *(yOld[1] + yOld[0])  +   constantFive /self.tau**2 *(self.y[1] + self.y[0]) - yNew[1] + self.g /self.dx * constantFive *(self.y[1] - self.y[0]) +  self.f(0)/self.mu * constantFive * cos(self.omegaD * t)
            #            print yNew[0], 't = ', t
            #input('press a key')
            yNew[-1] = -yNew[-2]

            if counter %100 == 0:
                from numpy import pi
                from matplotlib import pyplot
                pyplot.plot(self.y,self.x,'r.-')
                pyplot.xlim(-1.25,1.25)
                pyplot.ylim(-0.05,1.25)
                pyplot.title("T = " + str(2 * pi/self.omegaD)+  ' s\n time:'+ str(t))
                pyplot.draw()
                pyplot.pause(.001)
                pyplot.clf()



            yOld = copy(self.y)
            self.y = copy(yNew)
            t += self.tau
            counter += 1

a = 0
b = 1.
N = 200
tau = .0001
gamma = 20
mu = 0.003
tMax = 10
myWave = animatedWave(a,b,N,tau,tMax,gamma,mu,stabilityCheck=True)
myWave.initializeWave()
myWave.animate()
