
class animatedWave():

    def __init__(self,a,b,N,tau,tMax,gamma,stabilityCheck = False, c = 2):
        from numpy import arange
        self.L = b
        self.N = N
        self.tMax = tMax
        self.tau = tau
        self.gamma = gamma
        self.dx = (b - a)/N
        self.x = arange(a - self.dx/2., b + self.dx,self.dx)

        self.c = c

        print( stabilityCheck, 'here')
        from numpy import any
        if any(self.tau > self.dx/self.c) and stabilityCheck:
            print('Beware: your algorithm will be unstable.')
            import sys
            sys.exit()


    def initializeWave(self):
        from numpy import exp,zeros
        # Gaussian initial displacement
        self.v = 2 * exp( -160/self.L**2 * (self.x - self.L/2.)**2 )# - exp( -160/self.L**2 * (0 - self.L/2.)**2 )
        # Zero initial velocity
        self.y = zeros(self.N+2)


    def animate(self):
        from numpy import zeros_like,copy
        from matplotlib import pyplot
        constant = self.c**2 * self.tau**2/(2 * self.dx**2)
        constantTwo = 2. * self.tau * (2 + self.gamma * self.tau)

        yOld = zeros_like(self.y)
        yOld[1:self.N + 1] = -self.v[1:self.N + 1] * constantTwo/4. +( self.y[1:self.N + 1] + constant *(self.y[2:self.N + 2]- 2 * self.y[1:self.N + 1] + self.y[0:self.N]))
        yOld[0] = -yOld[1]
        yOld[-1] = -yOld[-2]
        t = 0
        counter = 0
        self.maxes = []
        while t < self.tMax:
            yNew = zeros_like(self.y)
            yNew[1:self.N + 1] = 1/(2 + self.gamma * self.tau) * (4 * self.y[1:self.N + 1] - 2 * yOld[1:self.N + 1] + self.gamma * self.tau * yOld[1:self.N + 1] + 4 * constant * (self.y[2:self.N + 2] - 2 * self.y[1: self.N + 1] + self.y[0:self.N]))
            yNew[0] =  -yNew[1]
            yNew[-1] = - yNew[-2]
            self.maxes.append(max(yNew))
            if counter % 50 == 0:
                pyplot.plot(self.x,self.y,'r.-')
                pyplot.ylim(-0.1,0.1)
                pyplot.draw()
                pyplot.pause(.000001)
                pyplot.clf()


            yOld = copy(self.y)
            self.y = copy(yNew)


            t += self.tau
            counter += 1
    def plotMaxes(self):
        from matplotlib import pyplot
        from numpy import linspace,exp
        t = linspace(0,self.tMax,len(self.maxes))
        pyplot.figure(2)
        pyplot.plot(t,self.maxes,'r.-')
        pyplot.plot(t,0.035 * exp(-self.gamma * t/2),'b-')
        pyplot.show()
a = 0
b = 1.
c = 2.
N = 200
tau = 0.001
gamma = 10
tMax = 25


myWave = animatedWave(a,b,N,tau,tMax,gamma,stabilityCheck = True)
myWave.initializeWave()
myWave.animate()
myWave.plotMaxes()
