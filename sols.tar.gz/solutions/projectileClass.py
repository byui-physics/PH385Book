

class projectileMotion():

    def __init__(self,g=9.8):
        self.g = g

    def setLaunchConditions(self,r,v):
        self.r = r
        self.v = v

    def calcLandingLocation(self):
        from numpy.linalg import norm
        from numpy import sqrt
        # Find the travel time
        a = -1/2. * self.g
        b = self.v[1]
        c = self.r[1]
        flightTime = (-b + sqrt(b**2 - 4 * a * c) ) / (2 * a)
        if flightTime < 0:
            flightTime = (-b - sqrt(b**2 - 4 * a * c) ) / (2 * a)
        flightRange = flightTime * self.v[0] 
        self.landingLocation = [flightRange,0]

Earth = projectileMotion()
Earth.setLaunchConditions([0,10],[10,20])
Earth.calcLandingLocation()
print Earth.landingLocation

Jupiter = projectileMotion(g=24)
Jupiter.setLaunchConditions([0,10],[10,20])
Jupiter.calcLandingLocation()
print Jupiter.landingLocation
