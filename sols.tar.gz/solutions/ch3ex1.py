from numpy import linspace,pi,sin,sinh  # Import the needed function
from matplotlib import pyplot
N=500             # the number of grid points
a=0
b=pi          # the left and right bounds
x=linspace(a,b,N)           # build the grid
print x
y = sin(x) * sinh(x)
print len(x)
pyplot.plot(x,y)
pyplot.show()
