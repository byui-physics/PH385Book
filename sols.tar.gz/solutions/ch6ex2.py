from numpy import sinh,arange,pi,cos,sin
from matplotlib import pyplot



class projectile():

    def __init__(self, g = 9.8, dt = 0.1):
        self.g = g
        self.dt = dt

        # For part d
    def C(self,v):
        return .198 + .295/(1 + exp((v - 35)/5) )

    def setDragSettings(self,A,C,m,rho,variableC = False):
        # Most of the logic here is for part d
        if not variableC:
            self.variableC = False
            self.dragFactor = 1/2. * A * C * rho/m  #Only include this line for previous parts
        else:
            self.variableC = True
            self.constant = 1/2. * A * rho/m


    def setInitialConditions(self,r,v):
        self.initialPos = r
        self.initialV = v

    def Euler(self):
        from numpy.linalg import norm

        self.x = [self.initialPos[0]]
        self.y = [self.initialPos[1]]
        vx = self.initialV[0]
        vy = self.initialV[1]

        while self.y[-1] > 0:

            speed = norm([vx,vy])
            if self.variableC:
                self.dragFactor = self.constant * self.C(speed)
            dragX = self.dragFactor * speed * vx
            dragY = self.dragFactor * speed * vy
            self.y.append(self.y[-1] + vy * self.dt)
            self.x.append(self.x[-1] + vx * self.dt)
            vy = vy - (dragY + self.g) * self.dt
            vx = vx - dragX * self.dt

    def plotTrajectory(self):
        from matplotlib import pyplot
        pyplot.plot(self.x,self.y)
        # pyplot.show()


from numpy import exp
speed = 49
angle = 35 * pi/180.
diameter = 0.075
radius = diameter /2
area = pi * radius**2
mass = .145
C = 0.5
rhoDenver = 0.96
rhoAtlanta = 1.22

trajectoryOne = projectile(dt=0.01)
trajectoryOne.setInitialConditions([0,1],[speed * cos(angle),speed * sin(angle)])
trajectoryOne.setDragSettings(area,C,mass,rhoDenver,variableC = False)
trajectoryOne.Euler()
trajectoryOne.plotTrajectory()

trajectoryTwo = projectile(dt=0.01)
trajectoryTwo.setInitialConditions([0,1],[speed * cos(angle),speed * sin(angle)])
trajectoryTwo.setDragSettings(area,C,mass,rhoAtlanta,variableC = False)
trajectoryTwo.Euler()
trajectoryTwo.plotTrajectory()
print abs(trajectoryTwo.x[-1] - trajectoryOne.x[-1]) * 3.28 # conversion from feet to meters
pyplot.show()
