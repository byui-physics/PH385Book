
class Poisson:

    def __init__(self,xDomain,yDomain,Nx,Ny):
        from numpy import linspace,meshgrid,zeros,arange

        # For part (c)
        #        self.dx = (xDomain[1] - xDomain[0])/Nx
        # self.dy = (yDomain[1] - yDomain[0])/Ny
        #self.x = arange(xDomain[0] - self.dx/2, xDomain[1] + self.dx,self.dx)
        #self.y = arange(yDomain[0] - self.dy/2, yDomain[1] + self.dy,self.dy)

        self.x,self.dx = linspace(xDomain[0],xDomain[1],Nx,retstep = True)
        self.y,self.dy = linspace(yDomain[0],yDomain[1],Ny,retstep = True)
        self.X, self.Y = meshgrid(self.x,self.y)
        self.V = zeros([Ny,Nx])
        self.chargeDensity = self.rho(self.x,self.y)
        self.Nx = Nx
        self.Ny = Ny
        print(len(self.chargeDensity))
        print(len(self.chargeDensity[0]))
        print(len(self.V))
        print(len(self.V[0]))
        print(self.chargeDensity)
        print(self.X)
        print(self.X[0:self.Nx -1:2,0:self.Nx -1:2])
        print(self.Y)
        print(self.Y[0:self.Ny -1:2,0:self.Ny -1:2])

        import sys
        #        sys.exit()
        self.eps = 8.854e-12
        self.Nx = Nx
        self.Ny = Ny

    def setOmega(self,omega):
        self.omega = omega

    def setOptimalOmega(self):
        from numpy import cos, pi, sqrt
        R = (self.dy**2 * cos( pi/self.Nx) + self.dx**2 * cos( pi/self.Ny))/(self.dx**2 + self.dy**2)
        self.omega = 2/(1 + sqrt(1 - R**2) )
        print("Using optimal omega = {:8.4f}".format(self.omega))
    def setBoundaryConditions(self):
        from numpy import pi, sin
        # self.V[:,0] = -2
        # self.V[:,-1] = 1

    def rho(self,x,y):
        import numpy
        from numpy import array
        if type(x) == numpy.ndarray:
            return array([[self.rho(n,p) for n in x] for p in y])
        if y <= 2 * x:
            return 1e-10
        else:
            return 0

    def relax(self,movie = True):
        import time
        from matplotlib import pyplot,cm
        from mpl_toolkits.mplot3d import Axes3D
        constant = (2/self.dx**2 + 2/self.dy**2)


        if movie:
            fig = pyplot.figure()

        shouldContinue = True
        counter = 0
        startTime = time.time()
        while shouldContinue:
            shouldContinue = False
            # Changed bounds on loop because now I need to loop over entire domain.
            print(self.Nx, 'check here')
            for i in range(1,self.Ny - 1):
                for j in range(1,self.Nx - 1):
                    if j == 2 * i:
                        continue
                    rhs = 1/constant *  ( (self.V[i+1,j] + self.V[i-1,j])/self.dy**2 + (self.V[i,j+1] + self.V[i,j-1] )/self.dx**2 + self.chargeDensity[i,j]/self.eps)

                    error = abs(self.V[i,j] - rhs)
                    self.V[i,j] = self.omega * rhs + (1 - self.omega) * self.V[i,j]

                    if error > 1e-4:
                        shouldContinue = True
            if counter % 10 ==0 and movie:
                pyplot.clf()
                ax = fig.gca(projection = '3d')
                ax.plot_surface(self.X,self.Y,self.V, cmap= cm.coolwarm)
                #ax.pbaspect = [1.0, 4.0, 1.0]
                #pyplot.axes().set_aspect('equal')
                #ax.set_zlim(0,1)
                ax.view_init(elev = 25.5,azim = 220)
                pyplot.draw()
                pyplot.pause(1e-4)
            counter += 1
        endTime = time.time()
        print('done')
        self.elapsedTime = endTime - startTime
        print(self.elapsedTime)
        pyplot.show()

    def plotEField(self,vS = [1,1]):
        from numpy import gradient,transpose,zeros
        from matplotlib import pyplot,cm
        from mpl_toolkits.mplot3d import Axes3D

        # Do the gradient manually
        Ex = zeros((self.Ny,self.Nx))
        Ey = zeros((self.Ny,self.Nx))
        for i in range(1,self.Ny-1):
            for j in range(1,self.Nx - 1):
                Ex[i,j] = -(self.V[i,j+1] - self.V[i,j-1])/( 2.0 * self.dx)
                Ey[i,j] = -(self.V[i+1,j] - self.V[i-1,j])/( 2.0 * self.dy)

        pyplot.figure(1)
        # Use numpy.gradient to do it.
        Ey,Ex = gradient(self.V,self.y,self.x,edge_order = 2)
        pyplot.quiver(self.X[0:len(self.X):vS[0],0:len(self.X[0]):vS[1]],self.Y[0:len(self.X):vS[0],0:len(self.X[0]):vS[1]],-Ex[0:len(self.X):vS[0],0:len(self.X[0]):vS[1]],-Ey[0:len(self.X):vS[0],0:len(self.X[0]):vS[1]])
        pyplot.axis('equal')
        fig = pyplot.figure(2)
        ax = fig.gca(projection = '3d')
        ax.plot_surface(self.X,self.Y,self.V, cmap= cm.coolwarm)
        #        ax.set_zlim(0,1)
        ax.view_init(elev = 25.5,azim = 220)
        pyplot.show()

xDomain = [0,0.2]
yDomain = [0,0.4]
Nx = 100
Ny = 50
vectorSkip = [4,5]
myPoiss = Poisson(xDomain,yDomain,Nx,Ny)
#myPoiss.setOmega(1.2)

myPoiss.setOptimalOmega()
myPoiss.setBoundaryConditions()
myPoiss.relax(movie = True)
myPoiss.plotEField(vS = vectorSkip)
