

class animatedWave():

    def __init__(self,a,b,N,tau,mu,T,omegaD,tMax,gamma,stabilityCheck = False, c = 2):
        from numpy import arange,sqrt
        self.L = b
        self.N = N
        self.tMax = tMax
        self.tau = tau
        self.samplingRate = 1/tau/10
        self.mu = mu
        self.gamma = gamma
        self.T = T
        self.omegaD = omegaD
        self.dx = (b - a)/N
        self.x = arange(a - self.dx/2., b + self.dx,self.dx)

        self.c = sqrt(T/mu)

        if self.tau > self.dx/self.c and stabilityCheck:
            print('Beware: your algorithm will be unstable.')
            import sys
            sys.exit()

    def f(self,x):
        import numpy
        if type(x) is numpy.ndarray:
            from numpy import array
            return array([self.f(var) for var in x])
        else:
            if 0.8 <= x <= 1.0:
                return 0.73
            else:
                return 0
    def DFT(self,samples):
        from numpy import exp,pi
        N = len(samples)
        self.gamma = []
        for k in range(N//2 + 1):
            gammaK = 0
            for n,yn in enumerate(samples):
                gammaK += yn * exp(-2j * pi * k * n/N )
            self.gamma.append(2 * gammaK/N)


    def initializeWave(self):
        from numpy import exp,zeros
        # Gaussian initial displacement
        self.v = 2 * exp( -160/self.L**2 * (self.x - self.L/2.)**2 ) - exp( -160/self.L**2 * (0 - self.L/2.)**2 )
        # Zero initial velocity
        self.y = zeros(self.N+2)


    def animate(self):
        from numpy import zeros_like,copy,cos
        from matplotlib import pyplot
        constant = self.c**2 * self.tau**2/(2 * self.dx**2)

        constantOne = 2. + self.gamma * self.tau
        constantTwo = 2. * self.c**2 * self.tau**2/self.dx**2

        yOld = zeros_like(self.y)
        yOld[1:self.N + 1] = -self.v[1:self.N + 1]* self.tau + 1./constantOne * (4 * self.y[1:self.N + 1] + constantTwo * (self.y[2:self.N + 2] - 2 * self.y[1:self.N + 1] + self.y[0:self.N])) + self.f(self.x[1:self.N + 1])/self.mu  * 2 * self.tau**2/constantOne
        yOld[0] = -yOld[1]
        yOld[-1] = -yOld[-2]
        t = 0
        counter = 0
        self.samples = []
        while t < self.tMax:
            yNew = zeros_like(self.y)
            yNew[1:self.N + 1] = 1/(2 + self.gamma * self.tau) * (4 * self.y[1:self.N + 1] - 2 * yOld[1:self.N + 1] + self.gamma * self.tau * yOld[1:self.N + 1]+ 4 * constant * (self.y[2:self.N + 2] - 2 * self.y[1: self.N + 1] + self.y[0:self.N])) + self.f(self.x[1:self.N + 1])/self.mu * cos(self.omegaD * t) * 2 * self.tau**2/(2 + self.gamma * self.tau)
            yNew[0] =  -yNew[1]
            yNew[-1] = - yNew[-2]
            if counter % 10 == 0:
                self.samples.append(self.y[3* self.N//4])
#            if counter % 5000 == 0:
#                pyplot.plot(self.x,self.y,'r.-')
#                pyplot.ylim(-0.005,0.005)
#                pyplot.draw()
#                pyplot.pause(.000001)
#                pyplot.clf()


            yOld = copy(self.y)
            self.y = copy(yNew)

            print(t)
            t += self.tau
            counter += 1

    def plotDFT(self):
        from numpy import linspace,abs
        from matplotlib import pyplot
        nSamples = len(self.samples)
        k = linspace(0,self.samplingRate/2,nSamples/2 + 1)
        pyplot.figure(2)
        pyplot.plot(k,abs(self.gamma))
        print('here')
        pyplot.show()


a = 0
b = 1.2
N = 200
tau = 0.0001
gamma = 60
tMax = 2.
mu = .003
T = 2.7
omegaD = 1080.


myWave = animatedWave(a,b,N,tau,mu,T,omegaD,tMax,gamma,stabilityCheck = True)
myWave.initializeWave()
myWave.animate()
myWave.DFT(myWave.samples)
myWave.plotDFT()

