class BVP():

    def __init__(self,a,b,N):
        from numpy import linspace
        self.L = b
        self.N = N
        self.x,self.dx = linspace(a,b,N,retstep=True)

    def initialize(self,T,mu):
        self.T = T
        self.mu = mu

    def loadMatrices(self):
        from numpy import zeros,sin,cos,eye
        # Load A
        self.A = zeros([self.N,self.N])
        self.A[0][0] = 1
        self.A[-1][-1] = 3./(2 * self.dx) - 2.
        self.A[-1][-2] = -2./self.dx
        self.A[-1][-3] = 1./(2 * self.dx)

        for i in range(1,self.N-1):
            self.A[i][i] = -2./self.dx**2
            self.A[i][i+1] = 1./self.dx**2
            self.A[i][i-1] = 1./self.dx**2

        # Load b
        self.B = eye(self.N)
        self.B[0,0] = 0.
        self.B[-1,-1] = 0
        print self.B
        import sys
        #sys.exit()

    def solveProblem(self):
        from scipy.linalg import eig
        from numpy import sqrt,pi
        self.eVals,self.eVecs = eig(self.A,self.B)
        self.omega = sqrt(-self.T/self.mu * self.eVals)/(2 * pi)
        self.key = sorted(range(len(self.omega)), key=lambda k: self.omega[k])
        print self.omega, 'before'
        self.omega = sorted(self.omega)
        print self.omega, 'after'
        import sys
        # sys.exit()

    def plot(self,mode):
        from numpy import real
        from matplotlib import pyplot
        prefactor = 1./max(abs(self.eVecs[:,self.key[mode]]))
        print self.eVecs[:,self.key[mode]], 'here'
        print prefactor, 'pfac'
        print max(self.eVecs[:,self.key[mode]]), 'max'
        pyplot.plot(self.x,prefactor * self.eVecs[:,self.key[mode]],'r.-')
        pyplot.title("mode:  " + str(mode + 1)+ '\n' +  str(real(self.omega[mode])) + " Hz")
        pyplot.show()


from matplotlib import pyplot
a = 0
b = 1.2
N = 100
T  = 127
mu = 0.003

myBVP = BVP(a,b,N)
myBVP.initialize(T,mu)
myBVP.loadMatrices()
myBVP.solveProblem()
print myBVP.omega[3], 'omega'
myBVP.plot(2)
