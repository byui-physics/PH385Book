from numpy import sinh,arange,pi,cos,sin
from matplotlib import pyplot



class projectile():

    def __init__(self, g = 9.8, dt = 0.1):
        self.g = g
        self.dt = dt

        # For part d
    def setInitialConditions(self,r,v):
        self.initialPos = r
        self.initialV = v

    def C(self,v):
        return .198 + .295/(1 + exp((v - 35)/5) )

    def setDragSettings(self,A,C,m,rho,variableC = False):
        # Most of the logic here is for part d
        if not variableC:
            self.variableC = False
            self.dragFactor = 1/2. * A * C * rho/m  #Only include this line for previous parts
        else:
            self.variableC = True
            self.constant = 1/2. * A * rho/m

    def getDerivs(self,varsVec):
        from numpy.linalg import norm
        from numpy import array
        v = varsVec[2:]
        xDeriv = v[0]
        yDeriv = v[1]
        speed = norm([v[0],v[1]])
        if self.variableC:
            self.dragFactor = self.constant * self.C(speed)
        dragX = self.dragFactor * speed * v[0]
        dragY = self.dragFactor * speed * v[1]
        vxDeriv = - dragX
        vyDeriv = - (dragY + self.g)
        return array([xDeriv,yDeriv,vxDeriv,vyDeriv])


    def Euler(self):
        from numpy.linalg import norm

        self.x = [self.initialPos[0]]
        self.y = [self.initialPos[1]]
        vx = [self.initialV[0]]
        vy = [self.initialV[1]]

        while self.y[-1] > 0:

            speed = norm([vx[-1],vy[-1]])
            if self.variableC:
                self.dragFactor = self.constant * self.C(speed)
            dragX = self.dragFactor * speed * vx[-1]
            dragY = self.dragFactor * speed * vy[-1]
            self.y.append(self.y[-1] + vy[-1] * self.dt)
            self.x.append(self.x[-1] + vx[-1] * self.dt)
            vy.append(vy[-1] - (dragY + self.g) * self.dt)
            vx.append(vx[-1] - dragX * self.dt)

    def RK4(self):
        from numpy import array

        self.x = [self.initialPos[0]]
        self.y = [self.initialPos[1]]
        vx = [self.initialV[0]]
        vy = [self.initialV[1]]
        r = array([self.x[-1],self.y[-1],vx[-1],vy[-1]])
        while self.y[-1] > 0:
            k1 = self.dt * self.getDerivs(r)
            k2 = self.dt * self.getDerivs(r + 1/2. * k1)
            k3 = self.dt * self.getDerivs(r + 1/2. * k2)
            k4 = self.dt * self.getDerivs(r + k3)
            r += 1/6. * (k1 + 2 * k2 + 2 * k3 + k4 )
            self.x.append(r[0])
            self.y.append(r[1])


    def RK2(self):
        from numpy import array

        self.x = [self.initialPos[0]]
        self.y = [self.initialPos[1]]
        vx = [self.initialV[0]]
        vy = [self.initialV[1]]
        r = array([self.x[-1],self.y[-1],vx[-1],vy[-1]])
        while self.y[-1] > 0:
            k1 = self.dt * self.getDerivs(r)
            k2 = self.dt * self.getDerivs(r + 1/2. * k1)
            r += k2
            self.x.append(r[0])
            self.y.append(r[1])

    def plotTrajectory(self):
        from matplotlib import pyplot
        pyplot.plot(self.x,self.y)
        # pyplot.show()


from numpy import exp
speed = 400#49
angle = 45 * pi/180.
diameter = 0.075
radius = diameter /2
area = pi * radius**2
mass = .145
C = 0.5
rho = 1.22

dt = .7
eulerRanges = []
rkRanges = []
rkFourRanges = []
dts = []
while dt > 1e-3:
    dts.append(dt)
    trajectoryOne = projectile(dt=dt)
    trajectoryOne.setInitialConditions([0,1],[speed * cos(angle),speed * sin(angle)])
    trajectoryOne.setDragSettings(area,C,mass,rho,variableC = True)
    trajectoryOne.Euler()
    eulerRanges.append(trajectoryOne.x[-1])
    trajectoryOne.setInitialConditions([0,1],[speed * cos(angle),speed * sin(angle)])
    trajectoryOne.RK2()
    rkRanges.append(trajectoryOne.x[-1])

    trajectoryOne.setInitialConditions([0,1],[speed * cos(angle),speed * sin(angle)])
    trajectoryOne.RK4()
    rkFourRanges.append(trajectoryOne.x[-1])
    dt /=1.5

pyplot.plot(dts,eulerRanges,label='Euler',linewidth=4.0)
pyplot.xscale('log')
#pyplot.yscale('log')
pyplot.plot(dts,rkRanges,label = "2nd order RK",linewidth=4.0)
pyplot.xscale('log')
pyplot.plot(dts,rkFourRanges,label = "4th order RK",linewidth=4.0)
pyplot.xticks(fontsize=30)
pyplot.yticks(fontsize=30)
pyplot.tight_layout()
pyplot.xscale('log')
pyplot.xlabel('Step size (s)')
pyplot.ylabel('Projectile Range')
pyplot.ylim(rkFourRanges[-1] - 10,rkFourRanges[-1] + 10)
pyplot.legend()
pyplot.savefig('Euler-RK2-RK4.png')
#pyplot.show()
