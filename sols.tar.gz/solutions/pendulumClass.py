class pendulum():

    def __init__(self, l, thetaI, omegaI, tMax = 10, dt = 0.1, g = 9.8):
        from numpy import arange
        
        self.g = g
        self.l = l
        self.theta = [thetaI]
        self.omega = [omegaI]
        self.dt = dt
        self.tMax = tMax
        self.time = arange(0,self.tMax,self.dt)



    def RK2(self):
        from  numpy import sin
        
        for t in self.time:
            thetaHalf = self.theta[-1] + self.dt/2. * self.omega[-1]
            omegaHalf = self.omega[-1] - self.dt/2. * self.g/self.l * sin(self.theta[-1])

            self.theta.append(self.theta[-1] + self.dt * omegaHalf)
            self.omega.append(self.omega[-1] - self.dt * self.g/self.l * sin(thetaHalf))

    def plot(self):
        from matplotlib import pyplot
        pyplot.plot(self.time,self.theta[:-1])
        pyplot.show()
