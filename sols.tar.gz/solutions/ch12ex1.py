
class HangingChain():

    def __init__(self,a,b,N):
        from numpy import arange,linspace
        self.L = b
        self.N = N
        self.dx = (b - a)/N
        self.x = linspace(a - self.dx/2., b + self.dx/2., N + 2)
        #        self.x = arange(a - self.dx/2.,b + self.dx,self.dx)
        self.g = 9.8

    def loadMatrices(self):
        from numpy import zeros,eye

        self.A = zeros([self.N + 2,self.N + 2])
        # Fill in top and bottom rows of A later
        self.A[-1,-1] = 1/2.
        self.A[-1,-2] = 1/2.
        self.A[0,0] = -1./self.dx
        self.A[0,1] = 1./self.dx


        for i in range(1,self.N + 1):
            self.A[i,i] = - 2 * self.x[i]/self.dx**2
            self.A[i,i-1] = self.x[i]/self.dx**2 - 1./(2 * self.dx)
            self.A[i,i+1] =  self.x[i]/self.dx**2 + 1./(2 * self.dx)

        self.B = eye(self.N + 2)
        self.B[-1,-1] = 0
        self.B[0,0] = 1./2
        self.B[0,1] = 1./2


    def solveProblem(self):
        from scipy.linalg import eig
        from numpy import pi, sqrt

        self.eVals,self.eVecs = eig(self.A,self.B)
        self.f = sqrt(-self.eVals * self.g) /(2 * pi)
        self.key = sorted(range(self.N + 2), key=lambda k: self.f[k])
        self.f = sorted(self.f)
        print(self.f[:5]) 

    def plot(self,mode):
        from matplotlib import pyplot
        from numpy import real
        pyplot.plot(self.eVecs[:,self.key[mode]],self.x,'r.-')
        pyplot.title('mode: ' + str(mode) + '\n' + str(real(self.f[mode])) + ' Hz')
        pyplot.axes().set_aspect('equal')
        pyplot.show()

a = 0.
b = 2.
N = 500
myChain = HangingChain(a,b,N)
myChain.loadMatrices()
myChain.solveProblem()
myChain.plot(3)


