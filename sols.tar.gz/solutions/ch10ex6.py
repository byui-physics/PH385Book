
from numpy import linspace,sin,cos,zeros,copy,mean,sqrt,array
from numpy.linalg import solve
from matplotlib import pyplot
import sys

a = 0
b = 2
N = 30
x,dx = linspace(a,b,N,retstep=True)

bMatrix = copy(x)
bMatrix[0] = 0.
bMatrix[-1] = 0.

#Load A matrix
aMatrix = zeros([N,N])
aMatrix[0,0] = 1.

# Quadratic derivative boundary condition
aMatrix[N-1,N-1] = 3./(2. * dx)
aMatrix[N-1,N-2] = -2. /dx
aMatrix[N-1,N-3] = 1./(2. * dx)

for i in range(1,N-1):
    aMatrix[i,i] = -2./dx**2 + 9.
    aMatrix[i,i+1] = 1./dx**2
    aMatrix[i,i-1] = 1./dx**2


solVec = solve(aMatrix,bMatrix)
yExact = x/9. - sin(3 * x)/(27 * cos(6) )
print solVec, 'approx'
print yExact, 'exact'
print sqrt(mean(abs(yExact - solVec)**2))

pyplot.plot(x,yExact)
pyplot.plot(x,solVec,'r.')
pyplot.show()
