from matplotlib import pyplot

class bouncing():

    def __init__(self,v,r):

        self.vx = v[0]
        self.vy = v[1]
        self.x = r[0]
        self.y = r[1]
        self.tau = 0.001
        self.g = 9.8



    def EulerBetterBounce(self):

        counter = 1
        while self.x < 10:
            self.x = self.x + self.vx * self.tau
            if self.y + self.vy * self.tau < 0:
                tempTau = -self.y/self.vy
                finishTau = self.tau - tempTau
                self.y = self.y + self.vy * tempTau
                self.vy = 0.95 *abs(self.vy)
                self.y = self.y + self.vy * finishTau
            else:
                self.y = self.y + self.vy * self.tau
                self.vy = self.vy - self.g * self.tau
            if counter % 10 == 0:
                pyplot.plot(self.x,self.y,'k.')
                pyplot.xlim(0,10)
                pyplot.ylim(0,1.2)
                pyplot.draw()
                pyplot.pause(0.01)
            counter += 1


    def Euler(self):

        counter = 1
        while self.x < 10:
            self.x = self.x + self.vx * self.tau
            self.y = self.y + self.vy * self.tau
            self.vy = self.vy - self.g * self.tau
            if self.y < 0:
                self.vy = abs(self.vy)
            if counter % 10 == 0:
                pyplot.plot(self.x,self.y,'k.')
                pyplot.xlim(0,10)
                pyplot.ylim(0,1.2)
                pyplot.draw()
                pyplot.pause(0.01)
            counter += 1

bouncer = bouncing([1,0],[0,1])
bouncer.EulerBetterBounce()
