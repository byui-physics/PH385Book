class BVP():

    def __init__(self,a,b,N):
        from numpy import linspace
        self.L = b
        self.N = N
        self.x,self.dx = linspace(a,b,N,retstep=True)

    def initialize(self,T,mu,omega):
        self.T = T
        self.mu = mu
        self.omega = omega

    def f(self,x):
        if isinstance(x,ndarray):
            from numpy import array
            return array([self.f(var) for var in x])
        else:
            if  0.8 <= x <= 1:
                return 0.73
            else:
               return 0.

    def loadMatrices(self):
        from numpy import zeros,sin,cos
        # Load A
        self.A = zeros([self.N,self.N])
        self.A[0][0] = 1
        self.A[-1][-1] = 1

        for i in range(1,self.N-1):
            self.A[i][i] = -2./self.dx**2 + self.mu * self.omega**2/self.T
            self.A[i][i+1] = 1./self.dx**2
            self.A[i][i-1] = 1./self.dx**2

        # Load b
        self.b = -self.f(self.x)/self.T# [-self.f(var)/self.T for var in self.x]
        self.b[0] = 0
        self.b[-1] = 0

    def solveProblem(self):
        from numpy.linalg import solve
        self.solution = solve(self.A,self.b)

    def plot(self):
        from matplotlib import pyplot
        pyplot.plot(self.x,self.solution,'r.')
        #        pyplot.show()
    def plotExact(self):
        from numpy import cos,sin
        yExact = -0.223681 * ( cos(6 - self.x) + cos(2 + 3 * self.x) + 16 * sin(3*self.x) - cos(2 - 3 * self.x) - cos(6 + self.x))
        pyplot.plot(self.x,yExact)

from matplotlib import pyplot
from numpy import linspace
a = 0
b = 1.2
N = 100
T  = 127
mu = 0.003
omega = linspace(400,1200,100)
amplitudes = []
myBVP = BVP(a,b,N)
for om in omega:
    myBVP.initialize(T,mu,om)
    myBVP.loadMatrices()
    myBVP.solveProblem()
    amplitudes.append(max(abs(myBVP.solution)))
    myBVP.plot()
    pyplot.draw()
    print(omega)
    #myBVP.plotExact()
     pyplot.ylim(-.05,.05)
    pyplot.pause(.1)
    pyplot.clf()
    #    pyplot.show()
pyplot.plot(omega,amplitudes)
pyplot.show()
