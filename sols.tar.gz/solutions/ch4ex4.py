(*This is a not python, but a Mathematica notebook*)
eqOne = f + fp * h + 1/2 fpp * h^2  + 1/6 fppp * h^3 +
    1/24 fpppp h^4 == fplus;
eqTwo = f - fp * h + 1/2 fpp * h^2  - 1/6 fppp * h^3 +
    1/24 fpppp h^4 == fminus;
Solve[{eqOne, eqTwo}, {fp, fpp}]
