from numpy import linspace, sin,cosh
from matplotlib import pyplot

a = 0
b = 5.
N = 100

#Use retstep to force linspace to
#return the stepsize too
x,dx = linspace(a,b,N,retstep=True)


y = sin(x) * cosh(x)

print(x)
print(y)
yp =(y[2:N]-y[0:N-2])/(2*dx)
ypp =(y[2:N]-2*y[1:N-1]+y[0:N-2])/dx**2

pyplot.plot(x,y)
pyplot.plot(x[1:N-1],yp)
pyplot.plot(x[1:N-1],ypp)
pyplot.show()
