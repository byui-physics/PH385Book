
class Poisson:

    def __init__(self,xDomain,yDomain,Nx,Ny):
        from numpy import linspace,meshgrid,zeros,arange


        self.x,self.dx = linspace(xDomain[0],xDomain[1],Nx,retstep = True)
        self.y,self.dy = linspace(yDomain[0],yDomain[1],Ny,retstep = True)
        self.X, self.Y = meshgrid(self.x,self.y)
        self.V = zeros([Ny,Nx])
        print(self.X)
        self.Nx = Nx
        self.Ny = Ny

    def setOmega(self,omega):
        self.omega = omega

    def setMask(self):
        from numpy import ones
        self.mask = ones([self.Ny,self.Nx])

        for i in range(self.Ny//3,2 * self.Ny//3,2):
            self.mask[i,self.Nx//3] = 0
            self.mask[i,2 * self.Nx//3] = 0
        for j in range(self.Nx//3,2 * self.Nx//3):
            self.mask[self.Ny//3,j] = 0
            self.mask[2 * self.Ny//3,j] = 0

    def setOptimalOmega(self):
        from numpy import cos, pi, sqrt
        R = (self.dy**2 * cos( pi/self.Nx) + self.dx**2 * cos( pi/self.Ny))/(self.dx**2 + self.dy**2)
        self.omega = 2/(1 + sqrt(1 - R**2) )
        print("Using optimal omega = {:8.4f}".format(self.omega))
    def setBoundaryConditions(self):
        from numpy import pi, sin
        self.V[:,0] = -1
        self.V[:,-1] = 1

    def relax(self,movie = True):
        import time
        from matplotlib import pyplot,cm
        from mpl_toolkits.mplot3d import Axes3D
        constant = (2/self.dx**2 + 2/self.dy**2)


        if movie:
            fig = pyplot.figure()

        shouldContinue = True
        counter = 0
        startTime = time.time()
        while shouldContinue:
            shouldContinue = False
            for i in range(1,self.Ny - 1):
                for j in range(1,self.Nx - 1):
                    rhs = 1/constant *  ( (self.V[i+1,j] + self.V[i-1,j])/self.dy**2 + (self.V[i,j+1] + self.V[i,j-1])/self.dx**2 )

                    error = abs(self.V[i,j] - rhs)
                    self.V[i,j] = (self.omega * rhs + (1 - self.omega) * self.V[i,j]) * self.mask[i,j]

                    if error > 1e-4:
                        shouldContinue = True

            if counter % 10 ==0 and movie:
                pyplot.clf()
                ax = fig.gca(projection = '3d')
                ax.plot_surface(self.X,self.Y,self.V, cmap= cm.flag)
                ax.set_zlim(-1,1)
                ax.view_init(elev = 25.5,azim = 220)
                pyplot.draw()
                pyplot.pause(1e-4)
            counter += 1
        endTime = time.time()
        print('done')
        self.elapsedTime = endTime - startTime
        print(self.elapsedTime)
        pyplot.show()

    def plotEField(self):
        from numpy import gradient,transpose
        from matplotlib import pyplot,cm
        from mpl_toolkits.mplot3d import Axes3D

        pyplot.figure(1)
        Ex,Ey = gradient(transpose(self.V),self.dx,self.dy)
        pyplot.quiver(self.X,self.Y,Ex*50,Ey*50)
        pyplot.axis('equal')
        fig = pyplot.figure(2)
        ax = fig.gca(projection = '3d')
        ax.plot_surface(self.X,self.Y,self.V, cmap= cm.coolwarm)
        ax.set_zlim(0,1)
        ax.view_init(elev = 25.5,azim = 30)
        pyplot.show()

xDomain = [-0.1,0.1]
yDomain = [0,0.4]
Nx = 50
Ny = 50
myPoiss = Poisson(xDomain,yDomain,Nx,Ny)
myPoiss.setOmega(1.2)
myPoiss.setMask()
#myPoiss.setOptimalOmega()
myPoiss.setBoundaryConditions()
myPoiss.relax(movie = True)
myPoiss.plotEField()

