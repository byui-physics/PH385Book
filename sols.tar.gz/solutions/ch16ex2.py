



class TwoDWave():

    def __init__(self,a,b,c,d,N,mu,sigma,tau,tMax):
        from numpy import linspace,meshgrid,sqrt
        self.tau = tau
        self.mu = mu
        self.sigma = sigma
        self.N = N
        self.tMax = tMax
        self.c = sqrt(sigma/mu)
        x,self.dx = linspace(a,b,N,retstep = True)
        y,self.dy = linspace(c,d,N,retstep = True)
        self.X,self.Y = meshgrid(x,y)
        print(self.dx)
        print( "Courant condition: ", self.dx/self.c/sqrt(2))
        if self.tau > 1/( sqrt(2)) *  self.dx/self.c:
            print(self.tau)
            print(1/( sqrt(2)) *  self.dx/self.c)
            print("Instability headed your way!")
            import sys
            sys.exit()

    def initializeWave(self):
        from numpy import zeros_like,exp

        self.z = exp(-5 *(self.X**2 + self.Y**2))
        self.v = zeros_like(self.z)
        self.z[0] = 0
        self.z[-1] = 0
        self.z[:,0] = 0
        self.z[:,-1] = 0
    def animate(self,movie=True):
        from numpy import zeros_like,copy
        from matplotlib import pyplot,cm
        from mpl_toolkits.mplot3d import Axes3D

        constant = self.sigma * self.tau**2 /(self.mu * self.dx**2)
        #        constant = self.c**2 * self.tau**2 /self.dx**2
        zOld = zeros_like(self.z)
        zOld[1:self.N - 1,1:self.N - 1] = - self.tau * self.v[1:self.N - 1,1:self.N - 1] + self.z[1:self.N -1, 1:self.N -1] + constant/2 * (self.z[2:self.N,1:self.N - 1] - 2 * self.z[1:self.N - 1,1:self.N - 1] + self.z[0:self.N - 2,1:self.N - 1] + self.z[1:self.N - 1,2:self.N] - 2 * self.z[1:self.N - 1,1:self.N - 1] + self.z[1:self.N - 1,0:self.N - 2])
        zOld[0] = 0
        zOld[-1] = 0
        zOld[:,0] = 0
        zOld[0,:] = 0

        counter = 0
        t = 0
        fig = pyplot.figure()
        self.singlePoint = []
        while t < self.tMax:
            zNew = zeros_like(self.z)
            zNew[1:self.N - 1,1:self.N - 1] = 2 * self.z[1:self.N - 1,1:self.N - 1] - zOld[1:self.N - 1, 1: self.N - 1] + constant * (self.z[2:self.N,1:self.N - 1] - 2 * self.z[1:self.N - 1,1:self.N - 1] + self.z[0:self.N - 2,1:self.N - 1] + self.z[1:self.N - 1,2:self.N] - 2 * self.z[1:self.N - 1,1:self.N - 1] + self.z[1:self.N - 1,0:self.N - 2])
            zNew[0] = 0
            zNew[-1] = 0
            zNew[:,0] = 0
            zNew[0,:] = 0
            self.singlePoint.append(self.z[int(self.N/2),int(self.N/2)])
            if counter %50 == 0 and movie:
                ax = fig.gca(projection='3d')
                ax.plot_surface(self.X,self.Y,self.z,cmap=cm.coolwarm)
                ax.set_zlim(-.5,.5)
                pyplot.draw()
                pyplot.title(' t = {}'.format(t))
                pyplot.pause(.0001)
                pyplot.clf()

            zOld = copy(self.z)
            self.z = copy(zNew)
            t += self.tau
            counter += 1
    def plotSinglePoint(self):

        from matplotlib import pyplot
        from numpy import linspace
        pyplot.plot(linspace(0,self.tMax,len(self.singlePoint)),self.singlePoint)
        pyplot.show()

a = -5
b = 5
c = -5
d = 5
N = 100
mu = 0.3
sigma = 2
tau = .005
tMax = 50
my2Dwave = TwoDWave(a,b,c,d,N,mu,sigma,tau,tMax)
my2Dwave.initializeWave()
my2Dwave.animate(movie = False)
my2Dwave.plotSinglePoint()

#from numpy import linspace, meshgrid,exp,sqrt,cos
#from matplotlib import pyplot
#from mpl_toolkits.mplot3d import Axes3D
