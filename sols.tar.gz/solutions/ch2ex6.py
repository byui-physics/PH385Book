def loopFunction(x):
    thesum = 0
    for n in range(1,1001):
        thesum += n * x**n

    return thesum

x = 0.75
loopVal = loopFunction(x)
checkVal = x /(1 -x)**2
print loopVal, checkVal
