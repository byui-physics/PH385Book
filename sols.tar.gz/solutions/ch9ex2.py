class pendulum():
    def __init__(self,tMax = 60, dt = .01,g=9.8,l= 9.8, q = 1/2.,Fd = 1.2,omegaD = 2/3.,resets = False):
        self.dt = dt
        self.tMax = tMax
        self.g = g
        self.l = l
        self.q = q
        self.Fd = Fd
        self.omegaD = omegaD
        self.resets = resets

    def setInitialConditions(self,theta,omega):
        self.theta = [theta]
        self.omega = [omega]
    def getDerivs(self,varsVec,t):
        from numpy import array,pi,sin
        from numpy.linalg import norm
        # Varsvec [theta,omega]
        dtheta = varsVec[1]
        dOmega = - self.g/self.l * sin(varsVec[0]) - self.q * varsVec[1] + self.Fd * sin(self.omegaD * t)

        return array([dtheta,dOmega])


    def RK4(self):
        from numpy import array

        r = array([self.theta[-1],self.omega[-1]])
        t = 0
        self.time = [t]
        while t < self.tMax:
            k1 = self.dt * self.getDerivs(r,t)
            k2 = self.dt * self.getDerivs(r + 1/2. * k1,t + 1/2. * self.dt)
            k3 = self.dt * self.getDerivs(r + 1/2. * k2,t + 1/2. * self.dt)
            k4 = self.dt * self.getDerivs(r + k3,t +  self.dt)
            r += 1/6. * (k1 + 2 * k2 + 2 * k3 + k4 )
            if r[0] > pi and self.resets:
                r[0] -= 2 *pi
            elif r[0] < -pi and self.resets:
                r[0] += 2 *pi
            self.theta.append( r[0]  )
            self.omega.append(r[1])
            t += self.dt
            self.time.append(t)



    def plot(self):
        from matplotlib import pyplot
        pyplot.figure()
        pyplot.plot(self.time,self.theta)
        #pyplot.show()

    def phaseSpace(self,show = True):
        from matplotlib import pyplot
        pyplot.scatter(self.theta,self.omega)
        pyplot.xlabel(r"$\theta$ (rads)")
        pyplot.ylabel(r"$\omega$ (rads/s)")
        font = {'family':'serif',
                'color': 'darkred',
                'weight': 'normal',
                'size':28}
        pyplot.text(-2.5,2.5,r"$\omega$ versus $\theta$     $F_D$ = " + str(self.Fd),fontdict=font)
        pyplot.xticks(fontsize=30)
        pyplot.yticks(fontsize=30)
        if show:
            pyplot.show()
        else:
            pyplot.savefig('PSplot-Chaos.png')


    def poincare(self):
        from numpy import pi
        from matplotlib import pyplot

        period = 2 * pi/self.omegaD
        inPhaseTimes = [n * period for n in range(0,int(self.tMax/period))]
        indices = [abs((array(self.time) - n)).argmin() for n in inPhaseTimes]
        specialTheta = [self.theta[n] for n in indices]
        specialOmega = [self.omega[n] for n in indices]
        pyplot.scatter(specialTheta,specialOmega)
        pyplot.xlabel(r"$\theta$ (rads)",fontsize=30)
        pyplot.ylabel(r"$\omega$ (rads/s)",fontsize=30)
        pyplot.xticks(fontsize=30)
        pyplot.yticks(fontsize=30)

        pyplot.show()

from numpy import pi,array,abs
from matplotlib import pyplot
import sys
theta = 0.2
omega = 0
pendulumOne = pendulum(tMax = 15000,dt = .04,Fd = 1.2,q=0.5,resets=True)
pendulumOne.setInitialConditions(theta,omega)
pendulumOne.RK4()
#pendulumOne.phaseSpace(show=False)
pendulumOne.poincare()
#pendulumOne.plot()
