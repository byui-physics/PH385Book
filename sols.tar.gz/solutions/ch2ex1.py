from numpy import arange,sin,log

x = arange(3,2000,3)
y = 3 *x**2 *sin(x) + log(x)
result = sum(y)

print result
