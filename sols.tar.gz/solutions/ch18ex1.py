class heat():


    def __init__(self,a,b,N,D,tau,stabilityCheck = True):
        from numpy import arange
        self.dx = (b - a)/N
        self.N = N
        self.L  = b
        self.tau = tau
        self.D = D
        print(self.dx**2/self.D)
        self.x = arange(a - self.dx/2,b + self.dx,self.dx)
        if stabilityCheck and self.tau > self.dx**2/self.D/2:
            import sys
            print('Watch out: Numerical instability headed your way.')
            sys.exit()

    def initialWaveForm(self,ftype,freq = 2):
        from numpy import pi, sin,exp
        if ftype == 'oscillatory':
            self.T = sin(2 * pi * self.x/self.L) + sin(3 * pi * self.x/self.L) + sin(4 * pi * self.x/self.L)
        else:
            self.T = exp(-40*(self.x/self.L - 0.5)**2)
    def animate(self,tMax,bc='fixed'):
        from numpy import zeros_like,copy
        from matplotlib import pyplot
        constant = self.D * self.tau/self.dx**2

        TNew = zeros_like(self.T)
        counter = 0
        t = 0
        while t < tMax:
            TNew[1:self.N + 1 ] = self.T[1:self.N + 1 ] + constant * (self.T[2:self.N + 2 ] - 2 * self.T[1:self.N + 1 ] + self.T[0:self.N ])
            if bc == 'fixed':
                TNew[0] = - TNew[1] # Boundary conditions for ghost points
                TNew[-1] = - TNew[-2]

            elif bc == 'insulating':
                TNew[0] =  TNew[1] # Boundary conditions for ghost points
                TNew[-1] =  TNew[-2]
            self.T = copy(TNew)

            if counter % 50 == 0:
                pyplot.plot(self.x,self.T,'r.-')
                pyplot.ylim(-1,1)
                pyplot.draw()
                pyplot.pause(.00001)
                pyplot.clf()
            counter += 1
            t += self.tau
            #    def exact(self,x,t):



a = 0
b = 3
N = 80
D = 2
tau = 0.00005


myHeat = heat(a,b,N,D,tau)
myHeat.initialWaveForm(ftype = 'exp')
myHeat.animate(10,bc = 'fixed')
