

class Phonon():

    def __init__(self,m1,m2,k1,k2,N):
        from numpy import arange,linspace
        self.m = [m1,m2]
        self.k = [k1,k2]
        self.N = N
        #        self.dx = (b - a)/N
        #self.x = linspace(a - self.dx/2., b + self.dx/2., N + 2)
        #        self.x = arange(a - self.dx/2.,b + self.dx,self.dx)
        # self.g = 9.8

    def loadMatrices(self):
        from numpy import zeros,eye

        self.A = zeros([self.N,self.N])
        # Fill in top and bottom rows of A later
        self.A[-1,-1] = (self.k[0] + self.k[1])/self.m[(self.N-1) % 2]
        self.A[-1,-2] = -self.k[(self.N - 1) % 2]/self.m[(self.N - 1) % 2]

        self.A[0,0] = (self.k[0] + self.k[1])/self.m[0]
        self.A[0,1] = -self.k[1]/self.m[0]

        #        self.A[0,0] = -1./self.dx
        #self.A[0,1] = 1./self.dx


        for i in range(1,self.N - 1):
            self.A[i,i] = (self.k[0] + self.k[1])/self.m[ i%2 ]
            self.A[i,i-1] = -self.k[i%2]/self.m[i%2]
            self.A[i,i+1] =  -self.k[(i-1)%2 ]/self.m[i%2]



    def solveProblem(self):
        from scipy.linalg import eig
        from numpy import pi, sqrt

        self.lam,self.u = eig(self.A)
        self.omega = sqrt(self.lam)
        self.key = sorted(range(self.N), key=lambda k: self.omega[k])
        self.omega = sorted(self.omega)

    def animate(self,mode):
        from matplotlib import pyplot
        from numpy import real,arange,cos,pi,linspace
        spacing = 2.5
        equilibriumPos = linspace(spacing,(self.N + 1) * spacing,self.N)
        print(equilibriumPos, 'here')
        #  import sys
        #sys.exit()
        counter = 0
        period = (2 * pi)/ real(self.omega[self.key[mode-1]])
        for t in arange(0,period * 1000,period/10):
            if counter %10 == 0:
                pyplot.plot(equilibriumPos + self.u[:,self.key[mode-1]] * cos(self.omega[mode-1] * t),[0.5 for t in equilibriumPos],'r.',markersize = 25)
                pyplot.xlim(-1,(self.N + 2) * spacing)
                pyplot.draw()
                pyplot.pause(.001)
                pyplot.clf()
            counter += 1

m1 = 1
m2 = 100
k1 = 1
k2 = 10
N = 10
myPh = Phonon(m1,m2,k1,k2,N)
myPh.loadMatrices()
myPh.solveProblem()
print(myPh.omega)
myPh.animate(3)


