from numpy import linspace, sin,cosh,zeros_like
from matplotlib import pyplot

a = 0
b = 5.
N = 100.

#Use retstep to force linspace to
#return the stepsize too
x,dx = linspace(a,b,N,retstep=True)


y = sin(x) * cosh(x)

# Build arrays of zeros that have the
#same length as y
yp = zeros_like(y)
ypp = zeros_like(y)

# Populate the inner values using centered-difference
# formulas
yp[1:N-1] =(y[2:N]-y[0:N-2])/(2*dx)
ypp[1:N-1] =(y[2:N]-2*y[1:N-1]+y[0:N-2])/dx**2

# Calculate derivatives at endpoints using
# linear extrapolation
#yp[0] = 2 * yp[1] - yp[2]
#yp[N-1] = 2 * yp[N-2] - yp[N-3]

#ypp[0] = 2 * ypp[1] - ypp[2]
#ypp[N-1] = 2 * ypp[N-2] - ypp[N-3]

# Calculate derivatives at endpoints using
# quadratic extrapolation
yp[0] = 3 * yp[1] - 3 * yp[2] + yp[3]
yp[N-1] = 3 * yp[N-2] - 3* yp[N-3] + yp[N-4]

ypp[0] = 3 * ypp[1] - 3 * ypp[2] + ypp[3]
ypp[N-1] = 3 * ypp[N-2] - 3 * ypp[N-3] + ypp[N-4]


pyplot.plot(x,y)
pyplot.plot(x,yp)
pyplot.plot(x,ypp)
pyplot.show()
