from numpy import exp,log


x = 10
while abs(x - exp(-x)) > 1e-5:

    x = exp(-x)
    print(x)


