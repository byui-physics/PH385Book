from numpy import linspace, sin,cosh,zeros_like,exp
from matplotlib import pyplot

h = [1.]
forward = (exp(h[-1]) - exp(0)) /h[-1]
centered = (exp(h[-1]) - exp(-h[-1])) /( 2 * h[-1])
centeredSecond =( exp(h[-1]) - 2 * exp(0) + exp(-h[-1]) )/h[-1]**2
errorsF = [abs(forward - 1.)]
errorsC = [abs(centered - 1.)]
errorsCsec = [abs(centeredSecond - 1.)]
while h[-1] > 1e-5:
    h.append(h[-1]/5.)
    forward = (exp(h[-1]) - exp(0)) /h[-1]
    centered = (exp(h[-1]) - exp(-h[-1])) /( 2 * h[-1])
    centeredSecond =( exp(h[-1]) - 2 * exp(0) + exp(-h[-1]) )/h[-1]**2
    errorsF.append(abs(forward - 1.))
    errorsC.append(abs(centered - 1.))
    errorsCsec.append(abs(centeredSecond - 1.))

print h
pyplot.loglog(h,errorsF,'*')
pyplot.loglog(h,errorsC,'d')
pyplot.loglog(h,errorsCsec,'s')
pyplot.ylim(1e-11,10)
pyplot.xlabel('h')
pyplot.ylabel('error')
pyplot.show()
