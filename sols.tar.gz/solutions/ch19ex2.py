

class CN():

    def __init__(self,a,b,N,tau,D):
        from numpy import arange
        self.L = b
        self.N = N
        self.tau = tau

        self.dx = (b - a)/N
        # cell-centered grid with ghost points.
        self.x = arange(a - self.dx/2, b + self.dx, self.dx)
        self.D = D

    def initializeTprofile(self):
        from numpy import sin, pi
        self.T = sin( pi * self.x/self.L)

    def loadMatrices(self):
        from numpy import zeros, insert,diag,matrix

        A = zeros([self.N +2, self.N + 2])
        self.B = zeros([self.N +2, self.N + 2])

        for i in range(1,self.N + 1):
            A[i,i-1] = - self.D
            A[i,i] = 2 * self.dx**2/self.tau  + 2 * self.D
            A[i,i+1] = - self.D

            self.B[i,i-1] = self.D
            self.B[i,i] = 2 * self.dx**2/self.tau  - 2 * self.D
            self.B[i,i+1] = self.D

        A[0,0] = 1/2.
        A[0,1] = 1/2.
        A[-1,-1] = 1/2.
        A[-1,-2] = 1/2.

        # Derivative boundary conditions
        #        A[0,0] = -1/self.dx
        #A[0,1] = 1/self.dx
        #A[-1,-1] = 1/self.dx
        #A[-1,-2] = -1/self.dx

        ud = insert(diag(A,1), 0, 0) # upper diagonal
        d = diag(A) # main diagonal
        ld = insert(diag(A,-1), self.N+1, 0) # lower diagonal
        # simplified matrix
        self.ab = matrix([ud,d,ld])
        print(self.ab)
    def animate(self,tMax):
        from numpy import dot,linspace
        from scipy.linalg import solve_banded
        from matplotlib import pyplot
        counter = 0
        t = 0
        errors = []
        while t < tMax:
            if counter %20 == 0:
                pyplot.plot(self.x,self.T,'r.-')
                pyplot.plot(self.x,self.getExact(t),'b-')
                pyplot.ylim(-0.1,1)
                pyplot.draw()
                pyplot.pause(1e-1)
                pyplot.clf()
            errors.append(max(abs(self.getExact(t) - self.T)))
            b = dot(self.B,self.T)
            # Boundary conditions: only really needed when the boundary condition isn't zero.
            b[0] = 0
            b[-1] = 0
            self.T = solve_banded((1,1),self.ab,b)

            counter += 1
            t += self.tau
        pyplot.figure(2)
        pyplot.scatter(linspace(0,tMax,len(errors)),errors)
        pyplot.show()

    def getExact(self,t):
        from numpy import sin,exp,pi
        return sin( pi * self.x /self.L) * exp(- pi**2 * self.D * t/self.L**2)
a = 0
b = 3
N = 100
D = 2
tau = 5e-2

myHeat = CN(a,b,N,tau,D)
myHeat.initializeTprofile()
myHeat.loadMatrices()
myHeat.animate(1)

# Code below is for part (c) to study the effect of tau and N
# on the accuracy of the algorithm.

from numpy import meshgrid,linspace,zeros_like
from matplotlib import pyplot,cm
from mpl_toolkits.mplot3d import Axes3D

taulist = linspace(1e-3,0.5,10)
nlist = range(10,100,10)

T,N = meshgrid(taulist,nlist)
errors = zeros_like(T)
for i,k in enumerate(T):
    for j,tau in enumerate(k):
        print(tau)
        print(i,j)
        myHeat = CN(a,b,N[i,j],tau,D)
        myHeat.initializeTProfile()
        myHeat.loadMatrices()
        myHeat.animate(10,30,movie = False)
        errors[i,j] = max(myHeat.errors)

fig = pyplot.figure()
ax = fig.gca(projection='3d')
ax.plot_surface(T,N,errors,cmap=cm.coolwarm)
ax.set_zlim(0,.0015)
ax.set_xlabel('tau')
ax.set_ylabel('N')
ax.set_zlabel('error')
pyplot.show()

