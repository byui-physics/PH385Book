from numpy import arange, e, cos
from matplotlib import pyplot
x = arange(0,10,.1)
y = e**(-0.25 * x) * cos(x)
pyplot.plot(x,y)
pyplot.show()
