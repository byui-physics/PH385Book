from numpy import arange,cos
from matplotlib import pyplot

a = 0
b = 2
N = 5000.
dx = (b  - a)/ N  # grid seperation
print dx

x = arange(a+dx/2,b+dx/2,dx)
print x
y = cos(x)
print y
print len(x)
area = sum(y) * dx
print area
pyplot.plot(x,y)
pyplot.show()
