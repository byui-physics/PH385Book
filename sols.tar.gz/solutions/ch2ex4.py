def loopFunction(N):
    thesum = 0
    for i in range(1,N+1):
        thesum += i

    return thesum

N = 100
loopVal = loopFunction(N)
checkVal = N * (N + 1)/2.
print loopVal, checkVal
