from numpy import linspace, sin,cosh, cos
from matplotlib import pyplot

h = 1e-5
forward = (sin(1 + h) - sin(1))/h
centered = (sin(1 + h) - sin(1 - h) ) /( 2 * h)
trueVal = cos(1)

print forward/trueVal, centered/trueVal
