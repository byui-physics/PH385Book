

class Phonon():

    def __init__(self,m,k,N):
        from numpy import arange,linspace
        self.m = m
        self.k = k
        self.N = N
        #        self.dx = (b - a)/N
        #self.x = linspace(a - self.dx/2., b + self.dx/2., N + 2)
        #        self.x = arange(a - self.dx/2.,b + self.dx,self.dx)
        # self.g = 9.8

    def loadMatrices(self):
        from numpy import zeros,eye

        self.A = zeros([self.N,self.N])
        # Fill in top and bottom rows of A later
        self.A[-1,-1] = 2.
        self.A[-1,-2] = -1.
        self.A[0,0] = 2
        self.A[0,1] = -1.

        #        self.A[0,0] = -1./self.dx
        #self.A[0,1] = 1./self.dx


        for i in range(1,self.N - 1):
            self.A[i,i] = 2.
            self.A[i,i-1] = -1.
            self.A[i,i+1] =  -1.



    def solveProblem(self):
        from scipy.linalg import eig
        from numpy import pi, sqrt

        self.lam,self.u = eig(self.A)
        self.omega = sqrt(self.lam * self.k/self.m) /(2 * pi)
        self.key = sorted(range(self.N), key=lambda k: self.omega[k])

    def animate(self,mode):
        from matplotlib import pyplot
        from numpy import real,arange,cos,pi,linspace
        spacing = 2.5
        equilibriumPos = linspace(spacing,(self.N + 1) * spacing,self.N)
        print(equilibriumPos, 'here')
        #  import sys
        #sys.exit()
        counter = 0
        for t in arange(0,(2 * pi)/ real(self.omega[self.key[mode]]) * 10,.5):
            if counter %10 == 0:
                pyplot.plot(equilibriumPos + self.u[:,self.key[mode]] * cos(self.omega[self.key[mode]] * t),[0.5 for t in equilibriumPos],'r.',markersize = 5)
                pyplot.xlim(-1,(self.N + 2) * spacing)
                pyplot.draw()
                pyplot.pause(.0001)
                pyplot.clf()
            counter += 1

m = 1
k = 1
N = 10
myPh = Phonon(m,k,N)
myPh.loadMatrices()
myPh.solveProblem()
print(myPh.omega)
myPh.animate(3)




