with open('massdata.txt', 'r') as f:
    data = f.readlines()

masses = [x.split()[3] for x in data]

totalMass = sum(masses)
xCM = 0
yCM = 0
zCM = 0
for dPoint in data:
    x = float(dPoint.split()[0])
    y = float(dPoint.split()[1])
    z = float(dPoint.split()[2])
    m = float(dPoint.split()[3])
    xCM += x * m
    yCM += y * m
    zCM += z * m

xCM /= totalMass
yCM /= totalMass
zCM /= totalMass
print(xCM, yCM,zCM)
