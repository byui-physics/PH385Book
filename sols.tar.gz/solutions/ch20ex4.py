
class Poisson():

    def __init__(self,xDomain,yDomain,Nx,Ny):
        from numpy import ones,linspace,meshgrid,zeros
        self.x = linspace(xDomain[0],xDomain[1],Nx)
        self.y = linspace(yDomain[0],yDomain[1],Ny)
        self.X,self.Y = meshgrid(self.x,self.y)
        self.V = zeros([Nx,Ny])
        self.epsilon = 8.854e-12
        self.dx = (xDomain[1] - xDomain[0])/Nx
        self.dy = (yDomain[1] - yDomain[0])/Ny
        self.Nx = Nx
        self.Ny = Ny

    def setOmega(self,omega):
        self.omega = omega

    def rho(self,r):
        if -0.2 <= r[0] <= 0.2 and 0.8 <= r[1] <= 1.2:
            return -1e-10
        else:
            return 0

    def getOptimalOmega(self):
        from numpy import cos,pi,sqrt
        R = (self.dy**2 * cos(pi/self.Nx) + self.dx**2 * cos(pi /self.Ny) )/(self.dx**2 + self.dy**2)
        self.omega = 2 /(1 + sqrt(1 - R**2))
        print('Using optimal omega = {:8.4f}'.format(self.omega))
    def setBoundaryConditions(self):
        self.V[0] = 1
        self.V[-1] = 1
    def relax(self,movie=True,close = True):
        import time
        from matplotlib import pyplot,cm
        from mpl_toolkits.mplot3d import Axes3D
        shouldContinue = True
        if movie:
            fig = pyplot.figure(1)
        counter = 0
        startTime = time.time()
        while shouldContinue:
            shouldContinue = False
            for i in range(1,self.Nx - 1):
                for j in range(1,self.Ny - 1):
                    rhs =  ( (self.V[i+1,j] + self.V[i-1,j])/self.dx**2 + (self.V[i,j+1] + self.V[i,j-1])/self.dy**2   + self.rho([self.x[i],self.y[j]])/self.epsilon )/(2/self.dx**2 + 2/self.dy**2)

                    error = abs(self.V[i,j] - rhs)
                    self.V[i,j] = self.omega * rhs + (1 - self.omega) * self.V[i,j]

                    if error > 1e-4:
                        shouldContinue = True
            if counter %1 == 0 and movie:
                pyplot.clf()
                ax = fig.gca(projection='3d')
                ax.plot_surface(self.X,self.Y,self.V,cmap=cm.coolwarm)
                ax.set_zlim(-1,1)
                ax.view_init(elev= 25.5,azim = 30)
                pyplot.draw()
                pyplot.pause(.0001)

            counter += 1
        if movie and close:
            pyplot.close()
        elif movie and not close:
            pyplot.show()
        endTime = time.time()
        self.elapsedTime = endTime - startTime
        print('Total # of iterations: {:3d}'.format(counter))
xBound = [-2,2]
yBound = [0,2]
Nx = 40
Ny = 40

myPoiss = Poisson(xBound,yBound,Nx,Ny)
#myPoiss.setOmega(1.2)
myPoiss.getOptimalOmega()
myPoiss.setBoundaryConditions()
myPoiss.relax(movie = True,close=False)
