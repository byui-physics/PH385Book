from numpy import sinh,arange,pi,cos,sin
from matplotlib import pyplot



class projectile():

    def __init__(self, g = 9.8, dt = 0.1):
        self.g = g
        self.dt = dt

        # For part d
    def C(self,v):
        from numpy import exp
        return .198 + .295/(1 + exp((v - 35)/5) )

    def setDragSettings(self,A,C,m,rho,variableC = False):
        # Most of the logic here is for part d
        if not variableC:
            self.variableC = False
            self.dragFactor = 1/2. * A * C * rho/m  #Only include this line for previous parts
        else:
            self.variableC = True
            self.constant = 1/2. * A * rho/m

    def turnOnMagnus(self, omega,m,S0 = 6.11e-5):
        from numpy import array
        self.Magnus = True
        self.magnusConstant = S0/m
        self.omega = array(omega)

    def getDerivs(self,varsVec):
        from numpy.linalg import norm
        from numpy import array,cross
        v = varsVec[3:]
        xDeriv = v[0]
        yDeriv = v[1]
        zDeriv = v[2]
        speed = norm([v[0],v[1],v[2]])
        if self.variableC:
            self.dragFactor = self.constant * self.C(speed)
        dragX = self.dragFactor * speed * v[0]
        dragY = self.dragFactor * speed * v[1]
        dragZ = self.dragFactor * speed * v[2]
        if self.Magnus:
            Magnus = self.magnusConstant * cross(self.omega, v)
        else:
            Magnus = [0,0,0]
        vxDeriv = - dragX + Magnus[0]
        vyDeriv = - (dragY + self.g - Magnus[1])
        vzDeriv = - dragZ + Magnus[2]


        return array([xDeriv,yDeriv,zDeriv,vxDeriv,vyDeriv,vzDeriv])

    def setInitialConditions(self,r,v):
        self.initialPos = r
        self.initialV = v

    def RK2(self):
        from numpy import array

        self.x = [self.initialPos[0]]
        self.y = [self.initialPos[1]]
        self.z = [self.initialPos[2]]
        vx = [self.initialV[0]]
        vy = [self.initialV[1]]
        vz = [self.initialV[2]]
        r = array([self.x[-1],self.y[-1],self.z[-1],vx[-1],vy[-1],vz[-1]])
        while self.y[-1] > 0:
            k1 = self.dt * self.getDerivs(r)
            k2 = self.dt * self.getDerivs(r + 1/2. * k1)
            r += k2
            self.x.append(r[0])
            self.y.append(r[1])
            self.z.append(r[2])


    def plotTrajectory(self):
        from matplotlib import pyplot
        from numpy import array
        pyplot.plot(array(self.x) * 3.28,array(self.y) * 3.28)
        # pyplot.show()


from numpy import pi, array
speed = 31.3
angle = 0 * pi/180.
diameter = 0.075
radius = diameter /2
area = pi * radius**2
mass = .145
C = 0.5
rho = 1.22
omega = array([0,1,0]) * 60 * 2 * pi

trajectoryOne = projectile(dt = 0.01)
trajectoryOne.setInitialConditions([0,2,0],[speed * cos(angle),speed * sin(angle),0])
trajectoryOne.setDragSettings(area,C,mass,rho,variableC = False)
trajectoryOne.turnOnMagnus(omega,mass)
trajectoryOne.RK2()
trajectoryOne.plotTrajectory()
pyplot.show()
