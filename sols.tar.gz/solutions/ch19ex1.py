
def Euler(yInitial,gamma,tau,tMax):
    from numpy import sqrt
    y = [yInitial]
    t = [0]
    while t[-1]< tMax:
        y.append(y[-1] - gamma * tau * y[-1])
        print(y[-1])
        t.append(t[-1] + tau)

    from matplotlib import pyplot
    pyplot.plot(t,y,'r.-')
    pyplot.ylim(-4,4)
    #    pyplot.show()

def partialImplicit(yInitial,gamma,tau,tMax):
    from numpy import sqrt
    y = [yInitial]
    t = [0]
    while t[-1]< tMax:
        y.append(y[-1]* ( 2 - gamma * tau)/(2 + gamma * tau))
        t.append(t[-1] + tau)

    from matplotlib import pyplot
    pyplot.plot(t,y,'g.-')
    pyplot.ylim(-4,4)
    #    pyplot.show()

def Implicit(yInitial,gamma,tau,tMax):
    from numpy import sqrt
    y = [yInitial]
    t = [0]
    while t[-1]< tMax:
        y.append(y[-1]/(1 + gamma * tau))
        t.append(t[-1] + tau)

    from matplotlib import pyplot
    pyplot.plot(t,y,'m.-')
    pyplot.ylim(-4,4)
    #    pyplot.show()

def plotExact(yI,gamma):
    from numpy import linspace,exp
    from matplotlib import pyplot
    t = linspace(0,10,100)
    y = yI * exp(-gamma * t)
    print(y)
    pyplot.plot(t,y,'b-')
    pyplot.show()



gamma = 3
tau = 2.1/gamma
#print(gamma,tau)
#Euler(1,gamma,tau,10)
#tau = 4/gamma
#partialImplicit(1,gamma,tau,10)
tau = 8.1/gamma
Implicit(1,gamma,tau,10)
plotExact(1,gamma)
