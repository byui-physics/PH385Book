from numpy import linspace, sin,cosh,zeros_like,exp,cos
from numpy.random import uniform
from matplotlib import pyplot


N = 1000
a = 0
b = 5
x,dx = linspace(a,b,N,retstep = True)
y = cos(x) + .001 * uniform(0,1,len(x))

yp = zeros_like(y)
ypp = zeros_like(y)

# Populate the inner values using centered-difference
# formulas
yp[1:N-1] =(y[2:N]-y[0:N-2])/(2*dx)
ypp[1:N-1] =(y[2:N]-2*y[1:N-1]+y[0:N-2])/dx**2



#Plot
pyplot.plot(x,y)
pyplot.plot(x,yp)
#pyplot.plot(x,ypp)
pyplot.show()
