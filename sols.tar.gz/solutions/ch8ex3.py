

class orbit():
    def __init__(self,tMax = 60,mEarth = 5.98e24,mJupiter = 1.898e27,mSun = 1.989e30,dt = .01):
        self.dt = dt
        self.tMax = tMax
        self.mEarth = mEarth
        self.mJupiter = mJupiter
        self.mSun = mSun

    def setInitialConditions(self,rE,vE,rJ,vJ):
        self.rE = [rE]
        self.vE = [vE]
        self.rJ = [rJ]
        self.vJ = [vJ]


    def getDerivs(self,varsVec):
        from numpy import array,pi,sin
        from numpy.linalg import norm

        rE = array(varsVec[:2])
        vE = varsVec[2:4]
        rJ = array(varsVec[4:6])
        vJ = varsVec[6:]

        xEDeriv = vE[0]
        yEDeriv = vE[1]

        xJDeriv = vJ[0]
        yJDeriv = vJ[1]

        rEJ = rJ - rE

        vxEDeriv = - 4 * pi**2 * rE[0]/norm(rE)**3 + 4 * pi**2 * self.mJupiter/self.mSun * rEJ[0]/norm(rEJ)**3
        vyEDeriv = - 4 * pi**2 * rE[1]/norm(rE)**3 + 4 * pi**2 * self.mJupiter/self.mSun * rEJ[1]/norm(rEJ)**3

        vxJDeriv = - 4 * pi**2 * rJ[0]/norm(rJ)**3 - 4 * pi**2 * self.mEarth/self.mSun * rEJ[0]/norm(rEJ)**3
        vyJDeriv = - 4 * pi**2 * rJ[1]/norm(rJ)**3 - 4 * pi**2 * self.mEarth/self.mSun * rEJ[1]/norm(rEJ)**3

        return array([xEDeriv,yEDeriv,vxEDeriv,vyEDeriv,xJDeriv,yJDeriv, vxJDeriv,vyJDeriv])


    def RK4(self):
        from numpy import array

        r = array([self.rE[0][0],self.rE[0][1],self.vE[0][0],self.vE[0][1],self.rJ[0][0],self.rJ[0][1],self.vJ[0][0],self.vJ[0][1]])
        t = 0
        self.time = [t]
        while t < self.tMax:
            k1 = self.dt * self.getDerivs(r)
            k2 = self.dt * self.getDerivs(r + 1/2. * k1)
            k3 = self.dt * self.getDerivs(r + 1/2. * k2)
            k4 = self.dt * self.getDerivs(r + k3)
            r += 1/6. * (k1 + 2 * k2 + 2 * k3 + k4 )
            self.rE.append( [r[0],r[1]]  )
            self.vE.append( [r[2],r[3]]  )
            self.rJ.append( [r[4],r[5]]  )
            self.vJ.append( [r[6],r[7]]  )
            t += self.dt
            self.time.append(t)


    def leapfrog(self):
        from numpy import array
        # Use 2nd order RK to perform the first time step
        t = 0
        self.time = [t]
        r = array([self.rE[0][0],self.rE[0][1],self.vE[0][0],self.vE[0][1],self.rJ[0][0],self.rJ[0][1],self.vJ[0][0],self.vJ[0][1]])
        k1 = self.dt * self.getDerivs(r)
        midPointVars = r + 1/2. * k1
        k2 = self.dt * self.getDerivs(r + 1/2. * k1)
        r += k2
        # First time step is done
        self.rE.append( [r[0],r[1]]  )
        self.vE.append( [r[2],r[3]]  )
        self.rJ.append( [r[4],r[5]]  )
        self.vJ.append( [r[6],r[7]]  )
        t += self.dt
        self.time.append(t)
        while t < self.tMax:
            # Find next
            midPointVars = midPointVars + self.dt * self.getDerivs(r)
            r = r + self.dt * self.getDerivs(midPointVars)

            self.rE.append( [r[0],r[1]]  )
            self.vE.append( [r[2],r[3]]  )
            self.rJ.append( [r[4],r[5]]  )
            self.vJ.append( [r[6],r[7]]  )

            t += self.dt
            self.time.append(t)

    def plot(self):
        from matplotlib import pyplot
        pyplot.figure()
        xE = [vars[0] for vars in self.rE]
        yE = [vars[1] for vars in self.rE]
        xJ = [vars[0] for vars in self.rJ]
        yJ = [vars[1] for vars in self.rJ]
        pyplot.plot(xE,yE)
        pyplot.plot(xJ,yJ)
        pyplot.show()


from numpy import pi,array,abs
from matplotlib import pyplot
import sys

rE = [1,0]
vE = [0,2 * pi]
rJ = [5.2,0]
vJ = [0, 2 * pi * 5.2/11.86]

myOrbits = orbit()
myOrbits.setInitialConditions(rE,vE,rJ,vJ)
myOrbits.leapfrog()
myOrbits.plot()
