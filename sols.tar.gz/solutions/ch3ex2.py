from numpy import linspace, arange,pi,sin, sinh

from matplotlib import pyplot

a = 0
b = pi
N = 10.
dx = (b  - a)/ N  # grid seperation
print dx

x = arange(a+dx/2,b+dx/2,dx)
print x
y = sin(x) * sinh(x)
print y
print len(x)
pyplot.plot(x,y)
pyplot.show()
